addKNM_ERKNM()
{

	web_set_user("supervisor", 
		lr_unmask("62175d1588f5d195a05ee422"), 
		"private.proverki.local:80");

	web_add_cookie("_yasc=xT4nyDnPIHPxgMSYHT57YbjUBRlG9V/kRizPxvY1XvW2wHDH; DOMAIN=yandex.ru");

	web_add_cookie("ys=wprid.1643638350173521-13608692661345350810-vla1-3034-vla-l7-balancer-8080-BAL-4638#musicchrome.0-0-4711111; DOMAIN=yandex.ru");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("private.proverki.local_5", 
		"URL=http://private.proverki.local/", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t339.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://yandex.ru/clck/click/dtype=elduse/path=tech.yaelements.dayuse/vars=-dayuse=832,-bro=chrome,-productname=weatherchrome,-ver=8-22-3,-ui=%7B09DD5623-D941-75FB-FF65-BEE4E3B516BA%7D,-brandID=yandex,-clid1=2231762/slots=0,0,0/*", "Referer=", ENDITEM, 
		"Url=/private/static/js/2.6caa3188.chunk.js", "Referer=", ENDITEM, 
		"Url=/private/static/js/main.b3e3c4c0.chunk.js", "Referer=", ENDITEM, 
		"Url=/private/static/media/FiraSans-Regular.34239e5e.woff2", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/private/static/media/FiraSans-Light.4e01567d.woff2", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/private/static/media/loader.76756433.gif", "Referer=http://private.proverki.local/private/auth", ENDITEM, 
		"Url=/private/faviconNew.ico", "Referer=http://private.proverki.local/private/auth", ENDITEM, 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	web_add_header("Origin", 
		"http://private.proverki.local");

	lr_think_time(8);

	web_custom_request("auth_5", 
		"URL=http://private.proverki.local/public/auth/authenticator/api/internalauth/auth?loaderKey=default", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/auth", 
		"Snapshot=t340.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("extendedprofile_6", 
		"URL=http://private.proverki.local/public/api/access-manager/api/users/current/extendedprofile", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/auth", 
		"Snapshot=t341.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/api/public-portal-url", "Referer=http://private.proverki.local/private/auth", ENDITEM, 
		LAST);

	web_url("organizations_14", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/auth", 
		"Snapshot=t342.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(4);

	web_url("roles_4", 
		"URL=http://private.proverki.local/private/api/admin/news/roles", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t343.inf", 
		"Mode=HTML", 
		LAST);

	web_url("published_11", 
		"URL=http://private.proverki.local/private/api/news/published?type=ANNOUNCEMENT&order=published,desc;", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t344.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("status-info-read_4", 
		"URL=http://private.proverki.local/private/api/signature/user/status-info-read", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t345.inf", 
		"Mode=HTML", 
		LAST);

	web_url("organizations_15", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t346.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/close.4a519fb6.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_custom_request("check-notification_4", 
		"URL=http://private.proverki.local/knm-service/api/knm-plan/check-notification", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t347.inf", 
		"Mode=HTML", 
		LAST);

	web_url("checklist-answer-types_3", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/checklist-answer-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t348.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("knm-expert-types", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/erknm/knm-expert-types", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t349.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-document-types_3", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/knm-document-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t350.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-document-types_4", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/erknm/knm-document-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t351.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-notice-methods_3", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/knm-notice-methods", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t352.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-responsible-types", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/erknm/knm-responsible-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t353.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("knm-types_3", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/knm-types?enabled_248=true", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t354.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("acquaintance-types", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/erknm/acquaintance-types", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t355.inf", 
		"Mode=HTML", 
		LAST);

	web_url("responsibility-type", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/erknm/responsibility-type", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t356.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("kind-result-decision", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/erknm/kind-result-decision", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t357.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("danger-class", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/danger-class", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t358.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("kno-organizations", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/kno-organizations", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t359.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/add.aa964dd5.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/private/static/media/info-italic.27ab16a9.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/private/static/media/delete.6395cd7b.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/private/static/media/settings.4811642b.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_custom_request("settings_5", 
		"URL=http://private.proverki.local/erknm-catalogs/api/settings", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t360.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("schedule_5", 
		"URL=http://private.proverki.local/erknm-catalogs/api/settings/schedule", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t361.inf", 
		"Mode=HTML", 
		LAST);

	web_url("published_12", 
		"URL=http://private.proverki.local/erknm-catalogs/api/news/published?type=ANNOUNCEMENT&order=published,desc;", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t362.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://private.proverki.local");

	web_custom_request("find-indexes_5", 
		"URL=http://private.proverki.local/erknm-index/api/knm/find-indexes?page=0&size=50&order=erpId%2Casc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t363.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"version\":\"ERKNM\"}", 
		LAST);

	web_url("published_13", 
		"URL=http://private.proverki.local/erknm-catalogs/api/news/published?type=ANNOUNCEMENT&order=published,desc;", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t364.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("knm-reason-types", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/erknm/knm-reason-types?isPm=false&isPlanned=false", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t365.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_url("organizations_16", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations?withDistrict=true", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t366.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/back.70f06ddf.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_custom_request("knm-reject-reason-types", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/erknm/knm-reject-reason-types?isPlaned=false", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t367.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("knm-plan-reason-change-types_3", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/erknm/knm-plan-reason-change-types", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t368.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(4);

	web_custom_request("supervision-type", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/supervision-type?uuids=0ae947de-79cd-1640-8179-fb67ca760249", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t369.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("check-list", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/check-list?uuidKno=0ae947de-79cd-1640-8179-fb67ca760249&uuidSupervision=0af4cd2e-78cb-109b-8178-e98123ff01b6", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t370.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_url("get-kno-supervision-uuid", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/constraint/get-kno-supervision-uuid?knoVersionId=0ae947de-79cd-1640-8179-fb67ca760249&supervisionVersionId=0af4cd2e-78cb-109b-8178-e98123ff01b6", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t371.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("requirement", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/requirement?uuidKno=0ae947de-79cd-1640-8179-fb67ca760249&uuidSupervision=0af4cd2e-78cb-109b-8178-e98123ff01b6", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t372.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("positions", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/positions?uniqueUuid=992dfa3d-57e4-4550-aa46-3871bbc45cd3", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t373.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("subject-type", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/subject-type?uniqueUuid=992dfa3d-57e4-4550-aa46-3871bbc45cd3", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t374.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("knm-kind", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/knm-kind?uniqueUuid=992dfa3d-57e4-4550-aa46-3871bbc45cd3", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t375.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("subject-sub-kind", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/subject-sub-kind?uniqueUuid=992dfa3d-57e4-4550-aa46-3871bbc45cd3", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t376.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("participant-positions", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/participant-positions?uniqueUuid=992dfa3d-57e4-4550-aa46-3871bbc45cd3", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t377.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("accepted-document", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/accepted-document?uniqueUuid=992dfa3d-57e4-4550-aa46-3871bbc45cd3", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t378.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("risk-indicatory", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/risk-indicatory?uniqueUuid=992dfa3d-57e4-4550-aa46-3871bbc45cd3", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t379.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("subject-kind", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/subject-kind?uniqueUuid=992dfa3d-57e4-4550-aa46-3871bbc45cd3", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t380.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_url("5", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/knm-reject-reason-types/5", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t381.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("5_2", 
		"URL=http://private.proverki.local/erknm-catalogs/api/catalogs/knm-reason-types/5", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t382.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/chevron-down.f78d5fc1.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	/*Connection ID 4 received buffer WebSocketReceive8*/

	/*Connection ID 5 received buffer WebSocketReceive9*/

	web_url("7743943819", 
		"URL=http://private.proverki.local/erknm-catalogs/api/fns/lookup/inn/7743943819", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t383.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/remove.7e6ce6a4.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_custom_request("okved", 
		"URL=http://private.proverki.local/erknm-catalogs/api/registry/export/okved?inn=7743943819&ogrn=5147746249965", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t384.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_add_header("Origin", 
		"http://private.proverki.local");

	lr_think_time(8);

	web_custom_request("knm_3", 
		"URL=http://private.proverki.local/erknm-knm/api/knm", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t385.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"BodyBinary={\"id\":null,\"erpId\":null,\"guid\":null,\"status\":null,\"year\":null,\"month\":null,\"creationDate\":null,\"publicationDate\":null,\"kind\":null,\"federalLaw\":null,\"title\":null,\"testPurchaseMethod\":null,\"testPurchaseDescription\":null,\"supervisionType\":null,\"startDateIsMonth\":null,\"approve\":null,\"reasons\":null,\"legalBases\":null,\"events\":null,\"signStatus\":null,\"knoOrganization\":null,\"inspectors\":null,\"rejectReasons\":null,\"organization\":null,\"riskCategory\""
		":null,\"objects\":null,\"links\":[],\"district\":{\"id\":\"1000000000000001\",\"name\":\"\\xD0\\xA0\\xD0\\x9E\\xD0\\xA1\\xD0\\xA1\\xD0\\x98\\xD0\\xAF - \\xD1\\x81\\xD0\\xBE\\xD1\\x81\\xD1\\x82\\xD0\\xB0\\xD0\\xB2 \\xD1\\x84\\xD0\\xB5\\xD0\\xB4\\xD0\\xB5\\xD1\\x80\\xD0\\xB0\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD1\\x8B\\xD1\\x85 \\xD0\\xBE\\xD0\\xBA\\xD1\\x80\\xD1\\x83\\xD0\\xB3\\xD0\\xBE\\xD0\\xB2\",\"center\":null,\"okatoTer\":null,\"okatoKod1\":null,\"okatoRazdel\":null,\"federalRegionCode\":null,\""
		"federalDistrict\":null},\"requirements\":null,\"deleted\":null,\"publishedStatus\":null,\"manualPublish\":null,\"published\":null,\"correlationToken\":null,\"createdBy\":null,\"updatedBy\":null,\"created\":null,\"updated\":null,\"note\":null,\"hash\":null,\"signed\":null,\"signatureInfo\":null,\"dateCreate\":null,\"classificationDateCreate\":null,\"publishDateCreate\":null,\"statusDateCreate\":null,\"pmErknm\":null,\"planId\":null,\"planGuid\":null,\"type\":{\"id\":5,\"name\":\""
		"\\xD0\\x92\\xD0\\xBD\\xD0\\xB5\\xD0\\xBF\\xD0\\xBB\\xD0\\xB0\\xD0\\xBD\\xD0\\xBE\\xD0\\xB2\\xD0\\xBE\\xD0\\xB5 \\xD0\\x9A\\xD0\\x9D\\xD0\\x9C\",\"code\":\"VP\",\"enabled\":false,\"weight\":1,\"label\":\"\\xD0\\x92\\xD0\\xBD\\xD0\\xB5\\xD0\\xBF\\xD0\\xBB\\xD0\\xB0\\xD0\\xBD\\xD0\\xBE\\xD0\\xB2\\xD0\\xBE\\xD0\\xB5 \\xD0\\x9A\\xD0\\x9D\\xD0\\x9C\",\"value\":\"VP\"},\"startDate\":\"2022-02-25\",\"stopDate\":\"2022-02-27\",\"prosecutorOrganization\":{\"id\":\"2\",\"code\":null,\"name\":\""
		"\\xD0\\x93\\xD0\\xB5\\xD0\\xBD\\xD0\\xB5\\xD1\\x80\\xD0\\xB0\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD0\\xB0\\xD1\\x8F \\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD0\\xBA\\xD1\\x83\\xD1\\x80\\xD0\\xB0\\xD1\\x82\\xD1\\x83\\xD1\\x80\\xD0\\xB0 \\xD0\\xA0\\xD0\\xBE\\xD1\\x81\\xD1\\x81\\xD0\\xB8\\xD0\\xB9\\xD1\\x81\\xD0\\xBA\\xD0\\xBE\\xD0\\xB9 \\xD0\\xA4\\xD0\\xB5\\xD0\\xB4\\xD0\\xB5\\xD1\\x80\\xD0\\xB0\\xD1\\x86\\xD0\\xB8\\xD0\\xB8\",\"address\":null,\"contacts\":null,\"federalDistrictId\":null,\"regionId\":null,\""
		"parentId\":null,\"enabled\":null},\"noticeMethod\":null,\"noticeDate\":null,\"documents\":null,\"knmErknm\":{\"accessToken\":null,\"knoOrganization\":{\"dictId\":\"af002594-a4f0-11eb-bcbc-0242ac130002\",\"dictVersionId\":\"0ae947de-79cd-1640-8179-fb67ca760249\"},\"decision\":{\"dateTimeDecision\":null,\"numberDecision\":null,\"placeDecision\":null,\"fioSigner\":null,\"titleSigner\":null},\"durationDays\":null,\"durationHours\":null,\"kindControl\":{\"dictId\":\""
		"1f27d942-a52e-11eb-bcbc-0242ac130002\",\"dictVersionId\":\"0af4cd2e-78cb-109b-8178-e98123ff01b6\"},\"kindKnm\":{\"dictId\":\"d2ec803a-a53e-11eb-bcbc-0242ac130002\",\"dictVersionId\":\"d2ec803a-a53e-11eb-bcbc-0242ac130003\"},\"reasonDocuments\":null,\"reasons\":[{\"reason\":{\"id\":null,\"type\":{\"id\":205,\"name\":\"(\\xD0\\xA4\\xD0\\x97 248) \\xD0\\x9D\\xD0\\xB0\\xD0\\xBB\\xD0\\xB8\\xD1\\x87\\xD0\\xB8\\xD0\\xB5 \\xD1\\x83 "
		"\\xD0\\xBA\\xD0\\xBE\\xD0\\xBD\\xD1\\x82\\xD1\\x80\\xD0\\xBE\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD0\\xBE\\xD0\\xB3\\xD0\\xBE (\\xD0\\xBD\\xD0\\xB0\\xD0\\xB4\\xD0\\xB7\\xD0\\xBE\\xD1\\x80\\xD0\\xBD\\xD0\\xBE\\xD0\\xB3\\xD0\\xBE) \\xD0\\xBE\\xD1\\x80\\xD0\\xB3\\xD0\\xB0\\xD0\\xBD\\xD0\\xB0 \\xD1\\x81\\xD0\\xB2\\xD0\\xB5\\xD0\\xB4\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD0\\xB9 \\xD0\\xBE \\xD0\\xBF\\xD1\\x80\\xD0\\xB8\\xD1\\x87\\xD0\\xB8\\xD0\\xBD\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD0\\xB8 "
		"\\xD0\\xB2\\xD1\\x80\\xD0\\xB5\\xD0\\xB4\\xD0\\xB0 (\\xD1\\x83\\xD1\\x89\\xD0\\xB5\\xD1\\x80\\xD0\\xB1\\xD0\\xB0) \\xD0\\xB8\\xD0\\xBB\\xD0\\xB8 \\xD0\\xBE\\xD0\\xB1 \\xD1\\x83\\xD0\\xB3\\xD1\\x80\\xD0\\xBE\\xD0\\xB7\\xD0\\xB5 \\xD0\\xBF\\xD1\\x80\\xD0\\xB8\\xD1\\x87\\xD0\\xB8\\xD0\\xBD\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F \\xD0\\xB2\\xD1\\x80\\xD0\\xB5\\xD0\\xB4\\xD0\\xB0 (\\xD1\\x83\\xD1\\x89\\xD0\\xB5\\xD1\\x80\\xD0\\xB1\\xD0\\xB0) "
		"\\xD0\\xBE\\xD1\\x85\\xD1\\x80\\xD0\\xB0\\xD0\\xBD\\xD1\\x8F\\xD0\\xB5\\xD0\\xBC\\xD1\\x8B\\xD0\\xBC \\xD0\\xB7\\xD0\\xB0\\xD0\\xBA\\xD0\\xBE\\xD0\\xBD\\xD0\\xBE\\xD0\\xBC \\xD1\\x86\\xD0\\xB5\\xD0\\xBD\\xD0\\xBD\\xD0\\xBE\\xD1\\x81\\xD1\\x82\\xD1\\x8F\\xD0\\xBC\",\"code\":\"ERKNM_5\",\"digitCode\":\"4.0.5\",\"hasText\":false,\"indicatorRiskRequired\":false,\"approveRequired\":false,\"dateRequired\":false,\"isDisabled\":false},\"text\":null,\"date\":null,\"main\":null,\"approveRequired\":null,\""
		"dateCreate\":null},\"riskIndikators\":null,\"numGuid\":null,\"dateCreate\":null}],\"dataContent\":null,\"prosecutorDocuments\":null,\"approve\":{\"approved\":null,\"approveRequired\":\"NON_REQUIRED\",\"approveNote\":null,\"dateDecision\":null,\"numberDecision\":null,\"fioSigner\":null,\"titleSigner\":null,\"noteAppeal\":null,\"rejectReasonType\":null,\"rejectReasonNote\":null,\"dateRejectReason\":null,\"prosecutorRegStatus\":null,\"note\":null,\"appeal\":null},\"organizations\":[{\"inn\":\""
		"7743943819\",\"ogrn\":\"5147746249965\",\"okveds\":null,\"addressFns\":null,\"organizationName\":\"\\xD0\\x9E\\xD0\\x91\\xD0\\xA9\\xD0\\x95\\xD0\\xA1\\xD0\\xA2\\xD0\\x92\\xD0\\x9E \\xD0\\xA1 \\xD0\\x9E\\xD0\\x93\\xD0\\xA0\\xD0\\x90\\xD0\\x9D\\xD0\\x98\\xD0\\xA7\\xD0\\x95\\xD0\\x9D\\xD0\\x9D\\xD0\\x9E\\xD0\\x99 \\xD0\\x9E\\xD0\\xA2\\xD0\\x92\\xD0\\x95\\xD0\\xA2\\xD0\\xA1\\xD0\\xA2\\xD0\\x92\\xD0\\x95\\xD0\\x9D\\xD0\\x9D\\xD0\\x9E\\xD0\\xA1\\xD0\\xA2\\xD0\\xAC\\xD0\\xAE \\\""
		"\\xD0\\xA2\\xD0\\xA0\\xD0\\x90\\xD0\\x9D\\xD0\\xA1\\xD0\\x9F\\xD0\\x9E\\xD0\\xA0\\xD0\\xA2\\xD0\\x9D\\xD0\\x9E-\\xD0\\xAD\\xD0\\x9A\\xD0\\xA1\\xD0\\x9F\\xD0\\x95\\xD0\\x94\\xD0\\x98\\xD0\\xA6\\xD0\\x98\\xD0\\x9E\\xD0\\x9D\\xD0\\x9D\\xD0\\x90\\xD0\\xAF \\xD0\\x9A\\xD0\\x9E\\xD0\\x9C\\xD0\\x9F\\xD0\\x90\\xD0\\x9D\\xD0\\x98\\xD0\\xAF \\\"\\xD0\\x9C\\xD0\\x95\\xD0\\x93\\xD0\\x90\\xD0\\x9F\\xD0\\x9E\\xD0\\x9B\\xD0\\x98\\xD0\\xA1\\\"\",\"mspCode\":null,\"checkSubjectResult\":null,\"dateCreate\":null,\""
		"act\":null,\"resultDecisions\":null,\"isAutocomplete\":true,\"isFiz\":null,\"guid\":null,\"isDocumentOrganization\":false}],\"objects\":[{\"address\":\"123\",\"objectType\":{\"dictId\":\"641d3956-a5b1-11eb-bcbc-0242ac130002\",\"dictVersionId\":\"0af4cd2e-78cb-109b-8178-ea2e8d4a0411\"},\"objectKind\":{\"dictId\":\"641d3e60-a5b1-11eb-bcbc-0242ac130002\",\"dictVersionId\":\"0ae95284-79cd-16d7-8179-e68a987d006a\"},\"objectSubKind\":{\"dictId\":\"641d3e60-a5b1-11eb-bcbc-0242ac130002\",\"dictVersionId\""
		":\"0ae95284-79cd-16d7-8179-e68a987d006a\"},\"riskCategory\":null,\"dangerClass\":{\"dictId\":\"aae78350-bdfd-12eb-8529-0242ac130003\",\"dictVersionId\":\"992a805a-f461-11eb-9a03-0242ac130003\"},\"guid\":null,\"streetGuid\":null,\"houseGuid\":null,\"roomGuid\":null,\"steadGuid\":null,\"addressFns\":null,\"autocomplete\":false,\"dateCreate\":null}],\"inspectors\":null,\"experts\":null,\"isHasCollaboratingOrganization\":null,\"collaboratingOrganizations\":null,\"events\":null,\""
		"collaboratingOrganizationChangeDate\":null,\"requirements\":null,\"approveDocs\":null,\"isChecklistsUsed\":null,\"checklists\":null,\"places\":null,\"organizationDocuments\":null,\"serviceDocument\":null,\"isRemote\":null,\"noteRemote\":null,\"withVideo\":null,\"isSelection\":null,\"selection\":null,\"isPresence\":null,\"isPresenceDelegateFullNames\":null,\"returnSelection\":null,\"attachmentsWeb\":null,\"documentRequestDate\":null,\"documentResponseDate\":null,\"manuallyRequirements\":null,\""
		"manuallyCheckList\":null,\"appealStatus\":null,\"changePlanReason\":null,\"isAppealed\":null,\"oldKnmNumber\":null,\"oldPlanNumber\":null,\"webNotificationInfos\":null},\"version\":\"ERKNM\",\"clientTime\":\"2022-02-24T13:10:25.229Z\"}", 
		LAST);

	web_custom_request("0ae947de-79cd-1640-8179-fb67ca760249", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/get-dictionary-value/af002594-a4f0-11eb-bcbc-0242ac130002/0ae947de-79cd-1640-8179-fb67ca760249", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t386.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("0af4cd2e-78cb-109b-8178-e98123ff01b6", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/get-dictionary-value/1f27d942-a52e-11eb-bcbc-0242ac130002/0af4cd2e-78cb-109b-8178-e98123ff01b6", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t387.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("0af4cd2e-78cb-109b-8178-ea2e8d4a0411", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/get-dictionary-value/641d3956-a5b1-11eb-bcbc-0242ac130002/0af4cd2e-78cb-109b-8178-ea2e8d4a0411", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t388.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("d2ec803a-a53e-11eb-bcbc-0242ac130003", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/get-dictionary-value/d2ec803a-a53e-11eb-bcbc-0242ac130002/d2ec803a-a53e-11eb-bcbc-0242ac130003", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t389.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("992a805a-f461-11eb-9a03-0242ac130003", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/get-dictionary-value/aae78350-bdfd-12eb-8529-0242ac130003/992a805a-f461-11eb-9a03-0242ac130003", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t390.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("0ae95284-79cd-16d7-8179-e68a987d006a", 
		"URL=http://private.proverki.local/erknm-catalogs/api/dictionaries/get-dictionary-value/641d3e60-a5b1-11eb-bcbc-0242ac130002/0ae95284-79cd-16d7-8179-e68a987d006a", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t391.inf", 
		"Mode=HTML", 
		LAST);

	web_url("links_3", 
		"URL=http://private.proverki.local/erknm-catalogs/api/knm/820703/links", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t392.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/exclamation-sign.e3b4a272.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_url("organizations_17", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations?withDistrict=true", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t393.inf", 
		"Mode=HTML", 
		LAST);

	web_url("820703", 
		"URL=http://private.proverki.local/erknm-catalogs/api/knm/820703", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/820703", 
		"Snapshot=t394.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://private.proverki.local");

	web_custom_request("find-previous_2", 
		"URL=http://private.proverki.local/erknm-catalogs/api/knm/find-previous?size=10&isFederalLaw248=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/820703", 
		"Snapshot=t395.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"year\":2022,\"inn\":[\"7743943819\"],\"ogrn\":[\"5147746249965\"]}", 
		LAST);

	web_custom_request("820703_2", 
		"URL=http://private.proverki.local/erknm-editors/api/knm/820703", 
		"Method=PUT", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/820703", 
		"Snapshot=t396.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}