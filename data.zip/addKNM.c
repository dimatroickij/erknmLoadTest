addKNM()
{

	web_set_user("supervisor", 
		lr_unmask("62175d1588f5d195a05ee422"), 
		"private.proverki.local:80");

	web_add_cookie("SESSION_TOKEN=; DOMAIN=private.proverki.local");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("private.proverki.local_4", 
		"URL=http://private.proverki.local/", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t287.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/js/2.6caa3188.chunk.js", "Referer=", ENDITEM, 
		"Url=/private/static/js/main.b3e3c4c0.chunk.js", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	/*Connection ID 2 received buffer WebSocketReceive4*/

	/*Connection ID 3 received buffer WebSocketReceive5*/

	web_add_header("Origin", 
		"http://private.proverki.local");

	lr_think_time(9);

	web_custom_request("auth_4", 
		"URL=http://private.proverki.local/public/auth/authenticator/api/internalauth/auth?loaderKey=default", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/auth", 
		"Snapshot=t288.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("extendedprofile_5", 
		"URL=http://private.proverki.local/public/api/access-manager/api/users/current/extendedprofile", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/auth", 
		"Snapshot=t289.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/api/public-portal-url", "Referer=http://private.proverki.local/private/auth", ENDITEM, 
		LAST);

	web_url("roles_3", 
		"URL=http://private.proverki.local/private/api/admin/news/roles", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t290.inf", 
		"Mode=HTML", 
		LAST);

	web_url("published_8", 
		"URL=http://private.proverki.local/private/api/news/published?type=ANNOUNCEMENT&order=published,desc;", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t291.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("status-info-read_3", 
		"URL=http://private.proverki.local/private/api/signature/user/status-info-read", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t292.inf", 
		"Mode=HTML", 
		LAST);

	web_url("organizations_10", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/auth", 
		"Snapshot=t293.inf", 
		"Mode=HTML", 
		LAST);

	web_url("organizations_11", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t294.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("check-notification_3", 
		"URL=http://private.proverki.local/knm-service/api/knm-plan/check-notification", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t295.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/add.aa964dd5.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/private/static/media/delete.6395cd7b.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/private/static/media/info-italic.27ab16a9.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/private/static/media/settings.4811642b.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_custom_request("settings_4", 
		"URL=http://private.proverki.local/private/api/settings", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t296.inf", 
		"Mode=HTML", 
		LAST);

	web_url("published_9", 
		"URL=http://private.proverki.local/private/api/news/published?type=ANNOUNCEMENT&order=published,desc;", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t297.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("schedule_4", 
		"URL=http://private.proverki.local/private/api/settings/schedule", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t298.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://private.proverki.local");

	web_custom_request("find-indexes_4", 
		"URL=http://private.proverki.local/private/api/knm/find-indexes?page=0&size=50&order=erpId%2Casc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t299.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"version\":\"ERP\"}", 
		LAST);

	web_url("checklist-answer-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/checklist-answer-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t300.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-address-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-address-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t301.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-document-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-document-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t302.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-delegate-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-delegate-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t303.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-execution-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-execution-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t304.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-notice-methods_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-notice-methods", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t305.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-inspectors_2", 
		"URL=http://private.proverki.local/private/api/knm-inspectors?knoId=10000001127", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t306.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-object-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-object-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t307.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-link-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-link-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t308.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-result-info-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-result-info-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t309.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-inspector-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-inspector-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t310.inf", 
		"Mode=HTML", 
		LAST);

	web_url("knm-subject-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-subject-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t311.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("knm-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-types?enabled_248=false", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t312.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_url("knm-violation-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-violation-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t313.inf", 
		"Mode=HTML", 
		LAST);

	web_url("test-purchase-methods_2", 
		"URL=http://private.proverki.local/private/api/catalogs/test-purchase-methods", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t314.inf", 
		"Mode=HTML", 
		LAST);

	web_url("risk-categories_2", 
		"URL=http://private.proverki.local/private/api/catalogs/risk-categories", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t315.inf", 
		"Mode=HTML", 
		LAST);

	web_url("violation-lawsuit-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/violation-lawsuit-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t316.inf", 
		"Mode=HTML", 
		LAST);

	web_url("published_10", 
		"URL=http://private.proverki.local/private/api/news/published?type=ANNOUNCEMENT&order=published,desc;", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t317.inf", 
		"Mode=HTML", 
		LAST);

	web_url("organizations_12", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations?withDistrict=true", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t318.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/back.70f06ddf.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_custom_request("knm-plan-reason-change-types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/erknm/knm-plan-reason-change-types", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t319.inf", 
		"Mode=HTML", 
		LAST);

	web_url("frequently-used_2", 
		"URL=http://private.proverki.local/private/api/catalogs/legal-basis/frequently-used?count=5", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t320.inf", 
		"Mode=HTML", 
		LAST);

	web_url("1_3", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-reject-reason-types/1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t321.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("1_4", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-reason-types/1", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t322.inf", 
		"Mode=HTML", 
		LAST);

	web_url("10000001127_2", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/functions/10000001127", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t323.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	web_url("0_2", 
		"URL=http://private.proverki.local/private/api/catalogs/knm-supervision-types/by-knm-type-and-subject-types/1/0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t324.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/chevron-down.f78d5fc1.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/private/static/media/right-double-arrow.044e469b.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_url("levels_2", 
		"URL=http://private.proverki.local/private/api/catalogs/legal-basis/levels", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t325.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/right-arrow.3276ccdb.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_url("types_2", 
		"URL=http://private.proverki.local/private/api/catalogs/legal-basis/types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t326.inf", 
		"Mode=HTML", 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive6*/

	/*Connection ID 3 received buffer WebSocketReceive7*/

	lr_think_time(19);

	web_url("1215212198", 
		"URL=http://private.proverki.local/private/api/fns/lookup/inn/1215212198", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t327.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/media/remove.7e6ce6a4.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	lr_think_time(9);

	web_url("requirement-templates_2", 
		"URL=http://private.proverki.local/private/api/requirement-templates?needQuestions=true&size=2000", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t328.inf", 
		"Mode=HTML", 
		LAST);

	web_url("9423_2", 
		"URL=http://private.proverki.local/private/api/requirement-templates/9423", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t329.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://private.proverki.local");

	lr_think_time(4);

	web_custom_request("knm_2", 
		"URL=http://private.proverki.local/knm-service/api/knm", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t330.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"BodyBinary={\"id\":null,\"erpId\":null,\"planId\":null,\"planGuid\":null,\"guid\":null,\"status\":null,\"year\":null,\"month\":2,\"creationDate\":null,\"publicationDate\":null,\"type\":{\"id\":1,\"name\":\"\\xD0\\x92\\xD0\\xBD\\xD0\\xB5\\xD0\\xBF\\xD0\\xBB\\xD0\\xB0\\xD0\\xBD\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD1\\x8F \\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD0\\xB2\\xD0\\xB5\\xD1\\x80\\xD0\\xBA\\xD0\\xB0\",\"code\":\"VP\",\"enabled\":true,\"weight\":1},\"kind\":{\"id\":1,\"name\":\""
		"\\xD0\\x92\\xD1\\x8B\\xD0\\xB5\\xD0\\xB7\\xD0\\xB4\\xD0\\xBD\\xD0\\xB0\\xD1\\x8F\",\"code\":\"TYPE_I\",\"enabled\":true,\"weight\":1},\"federalLaw\":{\"id\":0,\"name\":\"294 \\xD0\\xA4\\xD0\\x97\",\"code\":\"294\"},\"title\":null,\"testPurchaseMethod\":null,\"testPurchaseDescription\":null,\"supervisionType\":{\"id\":216,\"idBk\":216,\"guid\":\"20191118-1816-4483-4742-000000383432\",\"name\":\"\\xD0\\x92\\xD1\\x8B\\xD0\\xB1\\xD0\\xBE\\xD1\\x80\\xD0\\xBE\\xD1\\x87\\xD0\\xBD\\xD1\\x8B\\xD0\\xB9 "
		"\\xD0\\xBA\\xD0\\xBE\\xD0\\xBD\\xD1\\x82\\xD1\\x80\\xD0\\xBE\\xD0\\xBB\\xD1\\x8C \\xD0\\xBA\\xD0\\xB0\\xD1\\x87\\xD0\\xB5\\xD1\\x81\\xD1\\x82\\xD0\\xB2\\xD0\\xB0 \\xD0\\xB1\\xD0\\xB8\\xD0\\xBE\\xD0\\xBC\\xD0\\xB5\\xD0\\xB4\\xD0\\xB8\\xD1\\x86\\xD0\\xB8\\xD0\\xBD\\xD1\\x81\\xD0\\xBA\\xD0\\xB8\\xD1\\x85 \\xD0\\xBA\\xD0\\xBB\\xD0\\xB5\\xD1\\x82\\xD0\\xBE\\xD1\\x87\\xD0\\xBD\\xD1\\x8B\\xD1\\x85 \\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD0\\xB4\\xD1\\x83\\xD0\\xBA\\xD1\\x82\\xD0\\xBE\\xD0\\xB2.\",\"federalLaw\""
		":{\"id\":0,\"name\":\"294 \\xD0\\xA4\\xD0\\x97\",\"code\":\"294\"},\"digitCode\":\"1.176\",\"code\":\"SPV_216\",\"enabled\":true},\"startDate\":\"2022-02-24\",\"stopDate\":\"2022-02-25\",\"startDateIsMonth\":null,\"approve\":{\"inspectionTarget\":\"\\xD1\\x86\\xD0\\xB5\\xD0\\xBB\\xD1\\x8C\",\"startDate\":null,\"startDateIsMonth\":null,\"stopDate\":null,\"durationDays\":1,\"durationHours\":null,\"extDurationDays\":null,\"extDurationHours\":null,\"decisionPlace\":null,\"decisionDate\":null,\""
		"signerFullName\":null,\"signerPosition\":null,\"approved\":false,\"impossibleConductionReason\":null,\"documents\":[{\"id\":null,\"type\":{\"id\":1,\"code\":\"ORDER\"},\"atr\":\"1\",\"date\":\"2022-02-22\",\"main\":null,\"dateCreate\":null}],\"dateCreate\":null,\"streetGuid\":null,\"houseGuid\":null,\"roomGuid\":null,\"steadGuid\":null},\"reasons\":[{\"type\":{\"id\":107,\"name\":\"\\xD0\\x9F\\xD0\\xBE\\xD1\\x81\\xD1\\x82\\xD1\\x83\\xD0\\xBF\\xD0\\xBB\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD0\\xB5 "
		"\\xD0\\xB2 \\xD0\\xBE\\xD1\\x80\\xD0\\xB3\\xD0\\xB0\\xD0\\xBD \\xD0\\xB3\\xD0\\xBE\\xD1\\x81\\xD1\\x83\\xD0\\xB4\\xD0\\xB0\\xD1\\x80\\xD1\\x81\\xD1\\x82\\xD0\\xB2\\xD0\\xB5\\xD0\\xBD\\xD0\\xBD\\xD0\\xBE\\xD0\\xB3\\xD0\\xBE \\xD0\\xBA\\xD0\\xBE\\xD0\\xBD\\xD1\\x82\\xD1\\x80\\xD0\\xBE\\xD0\\xBB\\xD1\\x8F (\\xD0\\xBD\\xD0\\xB0\\xD0\\xB4\\xD0\\xB7\\xD0\\xBE\\xD1\\x80\\xD0\\xB0), "
		"\\xD0\\xBC\\xD1\\x83\\xD0\\xBD\\xD0\\xB8\\xD1\\x86\\xD0\\xB8\\xD0\\xBF\\xD0\\xB0\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD0\\xBE\\xD0\\xB3\\xD0\\xBE \\xD0\\xBA\\xD0\\xBE\\xD0\\xBD\\xD1\\x82\\xD1\\x80\\xD0\\xBE\\xD0\\xBB\\xD1\\x8F \\xD0\\xB7\\xD0\\xB0\\xD1\\x8F\\xD0\\xB2\\xD0\\xBB\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F \\xD0\\xBE\\xD1\\x82 \\xD0\\xB3\\xD1\\x80\\xD0\\xB0\\xD0\\xB6\\xD0\\xB4\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD0\\xBD\\xD0\\xB0, "
		"\\xD0\\xBE\\xD1\\x80\\xD0\\xB3\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD0\\xB7\\xD0\\xB0\\xD1\\x86\\xD0\\xB8\\xD0\\xB8 \\xD0\\xBE \\xD0\\xBF\\xD1\\x80\\xD0\\xB5\\xD0\\xB4\\xD0\\xBE\\xD1\\x81\\xD1\\x82\\xD0\\xB0\\xD0\\xB2\\xD0\\xBB\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD0\\xB8 \\xD0\\xBF\\xD1\\x80\\xD0\\xB0\\xD0\\xB2\\xD0\\xBE\\xD0\\xB2\\xD0\\xBE\\xD0\\xB3\\xD0\\xBE \\xD1\\x81\\xD1\\x82\\xD0\\xB0\\xD1\\x82\\xD1\\x83\\xD1\\x81\\xD0\\xB0, "
		"\\xD1\\x81\\xD0\\xBF\\xD0\\xB5\\xD1\\x86\\xD0\\xB8\\xD0\\xB0\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD0\\xBE\\xD0\\xB3\\xD0\\xBE \\xD1\\x80\\xD0\\xB0\\xD0\\xB7\\xD1\\x80\\xD0\\xB5\\xD1\\x88\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F (\\xD0\\xBB\\xD0\\xB8\\xD1\\x86\\xD0\\xB5\\xD0\\xBD\\xD0\\xB7\\xD0\\xB8\\xD0\\xB8) \\xD0\\xBD\\xD0\\xB0 \\xD0\\xBF\\xD1\\x80\\xD0\\xB0\\xD0\\xB2\\xD0\\xBE "
		"\\xD0\\xBE\\xD1\\x81\\xD1\\x83\\xD1\\x89\\xD0\\xB5\\xD1\\x81\\xD1\\x82\\xD0\\xB2\\xD0\\xBB\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F \\xD0\\xBE\\xD1\\x82\\xD0\\xB4\\xD0\\xB5\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD1\\x8B\\xD1\\x85 \\xD0\\xB2\\xD0\\xB8\\xD0\\xB4\\xD0\\xBE\\xD0\\xB2 \\xD0\\xB4\\xD0\\xB5\\xD1\\x8F\\xD1\\x82\\xD0\\xB5\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD0\\xBE\\xD1\\x81\\xD1\\x82\\xD0\\xB8 \\xD0\\xB8\\xD0\\xBB\\xD0\\xB8 "
		"\\xD1\\x80\\xD0\\xB0\\xD0\\xB7\\xD1\\x80\\xD0\\xB5\\xD1\\x88\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F (\\xD1\\x81\\xD0\\xBE\\xD0\\xB3\\xD0\\xBB\\xD0\\xB0\\xD1\\x81\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F) \\xD0\\xBD\\xD0\\xB0 \\xD0\\xBE\\xD1\\x81\\xD1\\x83\\xD1\\x89\\xD0\\xB5\\xD1\\x81\\xD1\\x82\\xD0\\xB2\\xD0\\xBB\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD0\\xB5 \\xD0\\xB8\\xD0\\xBD\\xD1\\x8B\\xD1\\x85 "
		"\\xD1\\x8E\\xD1\\x80\\xD0\\xB8\\xD0\\xB4\\xD0\\xB8\\xD1\\x87\\xD0\\xB5\\xD1\\x81\\xD0\\xBA\\xD0\\xB8 \\xD0\\xB7\\xD0\\xBD\\xD0\\xB0\\xD1\\x87\\xD0\\xB8\\xD0\\xBC\\xD1\\x8B\\xD1\\x85 \\xD0\\xB4\\xD0\\xB5\\xD0\\xB9\\xD1\\x81\\xD1\\x82\\xD0\\xB2\\xD0\\xB8\\xD0\\xB9, \\xD0\\xB5\\xD1\\x81\\xD0\\xBB\\xD0\\xB8 \\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD0\\xB2\\xD0\\xB5\\xD0\\xB4\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD0\\xB5 "
		"\\xD1\\x81\\xD0\\xBE\\xD0\\xBE\\xD1\\x82\\xD0\\xB2\\xD0\\xB5\\xD1\\x82\\xD1\\x81\\xD1\\x82\\xD0\\xB2\\xD1\\x83\\xD1\\x8E\\xD1\\x89\\xD0\\xB5\\xD0\\xB9 \\xD0\\xB2\\xD0\\xBD\\xD0\\xB5\\xD0\\xBF\\xD0\\xBB\\xD0\\xB0\\xD0\\xBD\\xD0\\xBE\\xD0\\xB2\\xD0\\xBE\\xD0\\xB9 \\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD0\\xB2\\xD0\\xB5\\xD1\\x80\\xD0\\xBA\\xD0\\xB8 \\xD0\\xB3\\xD1\\x80\\xD0\\xB0\\xD0\\xB6\\xD0\\xB4\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD0\\xBD\\xD0\\xB0, "
		"\\xD0\\xBE\\xD1\\x80\\xD0\\xB3\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD0\\xB7\\xD0\\xB0\\xD1\\x86\\xD0\\xB8\\xD0\\xB8 \\xD0\\xBF\\xD1\\x80\\xD0\\xB5\\xD0\\xB4\\xD1\\x83\\xD1\\x81\\xD0\\xBC\\xD0\\xBE\\xD1\\x82\\xD1\\x80\\xD0\\xB5\\xD0\\xBD\\xD0\\xBE \\xD0\\xBF\\xD1\\x80\\xD0\\xB0\\xD0\\xB2\\xD0\\xB8\\xD0\\xBB\\xD0\\xB0\\xD0\\xBC\\xD0\\xB8 \\xD0\\xBF\\xD1\\x80\\xD0\\xB5\\xD0\\xB4\\xD0\\xBE\\xD1\\x81\\xD1\\x82\\xD0\\xB0\\xD0\\xB2\\xD0\\xBB\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F "
		"\\xD0\\xBF\\xD1\\x80\\xD0\\xB0\\xD0\\xB2\\xD0\\xBE\\xD0\\xB2\\xD0\\xBE\\xD0\\xB3\\xD0\\xBE \\xD1\\x81\\xD1\\x82\\xD0\\xB0\\xD1\\x82\\xD1\\x83\\xD1\\x81\\xD0\\xB0, \\xD1\\x81\\xD0\\xBF\\xD0\\xB5\\xD1\\x86\\xD0\\xB8\\xD0\\xB0\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD0\\xBE\\xD0\\xB3\\xD0\\xBE \\xD1\\x80\\xD0\\xB0\\xD0\\xB7\\xD1\\x80\\xD0\\xB5\\xD1\\x88\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F (\\xD0\\xBB\\xD0\\xB8\\xD1\\x86\\xD0\\xB5\\xD0\\xBD\\xD0\\xB7\\xD0\\xB8\\xD0\\xB8), "
		"\\xD0\\xB2\\xD1\\x8B\\xD0\\xB4\\xD0\\xB0\\xD1\\x87\\xD0\\xB8 \\xD1\\x80\\xD0\\xB0\\xD0\\xB7\\xD1\\x80\\xD0\\xB5\\xD1\\x88\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F (\\xD1\\x81\\xD0\\xBE\\xD0\\xB3\\xD0\\xBB\\xD0\\xB0\\xD1\\x81\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F).\",\"code\":\"RSN_VP_CVII\",\"digitCode\":\"1.2.7\",\"hasText\":false,\"indicatorRiskRequired\":false,\"approveRequired\":false,\"dateRequired\":false,\"isDisabled\":false},\"date\":null,\"approveRequired\":false}],\""
		"legalBases\":[{\"documentName\":\"1\"}],\"events\":[{\"listId\":\"5832f7f8-e508-4577-9355-309c9c9949ed\",\"name\":\"\\xD0\\xBF\\xD0\\xB5\\xD1\\x80\\xD0\\xB5\\xD1\\x87\\xD0\\xB5\\xD0\\xBD\\xD1\\x8C\",\"startDate\":null,\"stopDate\":null}],\"signStatus\":null,\"knoOrganization\":{\"organization\":{\"id\":\"10000001127\",\"fullName\":\"\\xD0\\xA4\\xD0\\xB5\\xD0\\xB4\\xD0\\xB5\\xD1\\x80\\xD0\\xB0\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD0\\xB0\\xD1\\x8F "
		"\\xD1\\x81\\xD0\\xBB\\xD1\\x83\\xD0\\xB6\\xD0\\xB1\\xD0\\xB0 \\xD0\\xBF\\xD0\\xBE \\xD0\\xBD\\xD0\\xB0\\xD0\\xB4\\xD0\\xB7\\xD0\\xBE\\xD1\\x80\\xD1\\x83 \\xD0\\xB2 \\xD1\\x81\\xD1\\x84\\xD0\\xB5\\xD1\\x80\\xD0\\xB5 \\xD0\\xB7\\xD0\\xB4\\xD1\\x80\\xD0\\xB0\\xD0\\xB2\\xD0\\xBE\\xD0\\xBE\\xD1\\x85\\xD1\\x80\\xD0\\xB0\\xD0\\xBD\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F\"},\"collaboratingKnoName\":null,\"collaboratingOrganizations\":null,\"functions\":null},\"inspectors\":[{\"fullName\":\""
		"268014\\xD0\\xB0\\xD0\\xB2\\xD1\\x82\\xD0\\xBE \\xD0\\xA4\\xD0\\x98\\xD0\\x9E\",\"position\":\"268014\\xD0\\xB0\\xD0\\xB2\\xD1\\x82\\xD0\\xBE \\xD0\\x94\\xD0\\xBE\\xD0\\xBB\\xD0\\xB6\\xD0\\xBD\\xD0\\xBE\\xD1\\x81\\xD1\\x82\\xD1\\x8C\",\"type\":{\"id\":1,\"name\":\"\\xD0\\x9F\\xD1\\x80\\xD0\\xBE\\xD0\\xB2\\xD0\\xB5\\xD1\\x80\\xD1\\x8F\\xD1\\x8E\\xD1\\x89\\xD0\\xB8\\xD0\\xB9\",\"code\":\"TYPE_I\",\"enabled\":true},\"main\":true}],\"prosecutorOrganization\":{\"id\":\"2\",\"code\":null,\"name\":\""
		"\\xD0\\x93\\xD0\\xB5\\xD0\\xBD\\xD0\\xB5\\xD1\\x80\\xD0\\xB0\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD0\\xB0\\xD1\\x8F \\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD0\\xBA\\xD1\\x83\\xD1\\x80\\xD0\\xB0\\xD1\\x82\\xD1\\x83\\xD1\\x80\\xD0\\xB0 \\xD0\\xA0\\xD0\\xBE\\xD1\\x81\\xD1\\x81\\xD0\\xB8\\xD0\\xB9\\xD1\\x81\\xD0\\xBA\\xD0\\xBE\\xD0\\xB9 \\xD0\\xA4\\xD0\\xB5\\xD0\\xB4\\xD0\\xB5\\xD1\\x80\\xD0\\xB0\\xD1\\x86\\xD0\\xB8\\xD0\\xB8\",\"address\":null,\"contacts\":null,\"federalDistrictId\":null,\"regionId\":null,\""
		"parentId\":null,\"enabled\":null},\"rejectReasons\":null,\"organization\":{\"inn\":\"1215212198\",\"ogrn\":\"1161215058971\",\"organizationName\":\"\\xD0\\x9E\\xD0\\x91\\xD0\\xA9\\xD0\\x95\\xD0\\xA1\\xD0\\xA2\\xD0\\x92\\xD0\\x9E \\xD0\\xA1 \\xD0\\x9E\\xD0\\x93\\xD0\\xA0\\xD0\\x90\\xD0\\x9D\\xD0\\x98\\xD0\\xA7\\xD0\\x95\\xD0\\x9D\\xD0\\x9D\\xD0\\x9E\\xD0\\x99 "
		"\\xD0\\x9E\\xD0\\xA2\\xD0\\x92\\xD0\\x95\\xD0\\xA2\\xD0\\xA1\\xD0\\xA2\\xD0\\x92\\xD0\\x95\\xD0\\x9D\\xD0\\x9D\\xD0\\x9E\\xD0\\xA1\\xD0\\xA2\\xD0\\xAC\\xD0\\xAE \\\"\\xD0\\x94\\xD0\\x9E\\xD0\\x9C \\xD0\\xA1\\xD0\\x95\\xD0\\xA0\\xD0\\x92\\xD0\\x98\\xD0\\xA1\\\"\",\"type\":{\"id\":0,\"name\":\"\\xD0\\xAE\\xD0\\x9B/\\xD0\\x98\\xD0\\x9F\",\"code\":\"UL_IP\",\"federalLaw\":null,\"enabled\":true,\"weight\":0},\"registrationDate\":\"2016-08-09\",\"licenseReasonStartDate\":null,\"licenseReasonKnmEndDate\""
		":null,\"autocomplete\":true,\"mspCode\":null},\"riskCategory\":null,\"objects\":null,\"noticeMethod\":null,\"noticeDate\":null,\"documents\":null,\"links\":[],\"district\":{\"id\":\"1000000000000001\",\"name\":\"\\xD0\\xA0\\xD0\\x9E\\xD0\\xA1\\xD0\\xA1\\xD0\\x98\\xD0\\xAF - \\xD1\\x81\\xD0\\xBE\\xD1\\x81\\xD1\\x82\\xD0\\xB0\\xD0\\xB2 \\xD1\\x84\\xD0\\xB5\\xD0\\xB4\\xD0\\xB5\\xD1\\x80\\xD0\\xB0\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD1\\x8B\\xD1\\x85 "
		"\\xD0\\xBE\\xD0\\xBA\\xD1\\x80\\xD1\\x83\\xD0\\xB3\\xD0\\xBE\\xD0\\xB2\",\"center\":null,\"okatoTer\":null,\"okatoKod1\":null,\"okatoRazdel\":null,\"federalRegionCode\":null,\"federalDistrict\":null},\"requirements\":[{\"name\":\"10798\\xD0\\xB0\\xD0\\xB2\\xD1\\x82\\xD0\\xBE \\xD0\\x9D\\xD0\\xB0\\xD0\\xB8\\xD0\\xBC\\xD0\\xB5\\xD0\\xBD\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD0\\xB5\",\"template\":{\"id\":9423,\"name\":\"10798\\xD0\\xB0\\xD0\\xB2\\xD1\\x82\\xD0\\xBE "
		"\\xD0\\x9D\\xD0\\xB0\\xD0\\xB8\\xD0\\xBC\\xD0\\xB5\\xD0\\xBD\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD0\\xB5\",\"byDefault\":false,\"knoOrganizationId\":\"10000001127\",\"supervisionType\":216,\"requirements\":[{\"guid\":null,\"id\":60904,\"name\":\"10798\\xD0\\xB0\\xD0\\xB2\\xD1\\x82\\xD0\\xBE \\xD0\\x9D\\xD0\\xB0\\xD0\\xB8\\xD0\\xBC\\xD0\\xB5\\xD0\\xBD\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD0\\xB5 \\xD0\\x9D\\xD0\\x9F\\xD0\\x90\",\"props\":\""
		"10798\\xD0\\xB0\\xD0\\xB2\\xD1\\x82\\xD0\\xBE \\xD0\\xA4\\xD0\\xBE\\xD1\\x80\\xD0\\xBC\\xD1\\x83\\xD0\\xBB\\xD0\\xB8\\xD1\\x80\\xD0\\xBE\\xD0\\xB2\\xD0\\xBA\\xD0\\xB0\",\"number\":\"107981\",\"date\":\"2022-02-17\",\"paragraph\":null,\"part\":null,\"article\":null,\"index\":0}],\"deleted\":false},\"documents\":[{\"guid\":null,\"id\":60904,\"name\":\"10798\\xD0\\xB0\\xD0\\xB2\\xD1\\x82\\xD0\\xBE "
		"\\xD0\\x9D\\xD0\\xB0\\xD0\\xB8\\xD0\\xBC\\xD0\\xB5\\xD0\\xBD\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD0\\xB5 \\xD0\\x9D\\xD0\\x9F\\xD0\\x90\",\"props\":\"10798\\xD0\\xB0\\xD0\\xB2\\xD1\\x82\\xD0\\xBE \\xD0\\xA4\\xD0\\xBE\\xD1\\x80\\xD0\\xBC\\xD1\\x83\\xD0\\xBB\\xD0\\xB8\\xD1\\x80\\xD0\\xBE\\xD0\\xB2\\xD0\\xBA\\xD0\\xB0\",\"number\":\"107981\",\"date\":\"2022-02-17\",\"paragraph\":null,\"part\":null,\"article\":null,\"index\":0}],\"knoOrganization\":{\"id\":\"10000001127\",\"fullName\""
		":\"\\xD0\\xA4\\xD0\\xB5\\xD0\\xB4\\xD0\\xB5\\xD1\\x80\\xD0\\xB0\\xD0\\xBB\\xD1\\x8C\\xD0\\xBD\\xD0\\xB0\\xD1\\x8F \\xD1\\x81\\xD0\\xBB\\xD1\\x83\\xD0\\xB6\\xD0\\xB1\\xD0\\xB0 \\xD0\\xBF\\xD0\\xBE \\xD0\\xBD\\xD0\\xB0\\xD0\\xB4\\xD0\\xB7\\xD0\\xBE\\xD1\\x80\\xD1\\x83 \\xD0\\xB2 \\xD1\\x81\\xD1\\x84\\xD0\\xB5\\xD1\\x80\\xD0\\xB5 \\xD0\\xB7\\xD0\\xB4\\xD1\\x80\\xD0\\xB0\\xD0\\xB2\\xD0\\xBE\\xD0\\xBE\\xD1\\x85\\xD1\\x80\\xD0\\xB0\\xD0\\xBD\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F\",\"districtName\""
		":null,\"districtId\":null,\"byDefault\":true,\"isEnable\":true},\"supervisionType\":{\"id\":216,\"idBk\":216,\"guid\":\"20191118-1816-4483-4742-000000383432\",\"name\":\"\\xD0\\x92\\xD1\\x8B\\xD0\\xB1\\xD0\\xBE\\xD1\\x80\\xD0\\xBE\\xD1\\x87\\xD0\\xBD\\xD1\\x8B\\xD0\\xB9 \\xD0\\xBA\\xD0\\xBE\\xD0\\xBD\\xD1\\x82\\xD1\\x80\\xD0\\xBE\\xD0\\xBB\\xD1\\x8C \\xD0\\xBA\\xD0\\xB0\\xD1\\x87\\xD0\\xB5\\xD1\\x81\\xD1\\x82\\xD0\\xB2\\xD0\\xB0 "
		"\\xD0\\xB1\\xD0\\xB8\\xD0\\xBE\\xD0\\xBC\\xD0\\xB5\\xD0\\xB4\\xD0\\xB8\\xD1\\x86\\xD0\\xB8\\xD0\\xBD\\xD1\\x81\\xD0\\xBA\\xD0\\xB8\\xD1\\x85 \\xD0\\xBA\\xD0\\xBB\\xD0\\xB5\\xD1\\x82\\xD0\\xBE\\xD1\\x87\\xD0\\xBD\\xD1\\x8B\\xD1\\x85 \\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD0\\xB4\\xD1\\x83\\xD0\\xBA\\xD1\\x82\\xD0\\xBE\\xD0\\xB2.\",\"federalLaw\":{\"id\":0,\"name\":\"294 \\xD0\\xA4\\xD0\\x97\",\"code\":\"294\"},\"digitCode\":\"1.176\",\"code\":\"SPV_216\",\"enabled\":true},\"guid\":null}],\"deleted\":null"
		",\"publishedStatus\":null,\"manualPublish\":null,\"published\":null,\"correlationToken\":null,\"createdBy\":null,\"updatedBy\":null,\"created\":null,\"updated\":null,\"note\":null,\"hash\":null,\"signed\":null,\"signatureInfo\":null,\"dateCreate\":null,\"classificationDateCreate\":null,\"publishDateCreate\":null,\"statusDateCreate\":null,\"knmErknm\":null,\"pmErknm\":null,\"version\":\"ERP\",\"clientTime\":\"2022-02-22T14:06:44.311Z\"}", 
		LAST);

	web_custom_request("find-previous", 
		"URL=http://private.proverki.local/private/api/knm/find-previous?size=10", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t331.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"year\":2022,\"inn\":[\"1215212198\"],\"ogrn\":[\"1161215058971\"]}", 
		LAST);

	web_revert_auto_header("Origin");

	web_url("links_2", 
		"URL=http://private.proverki.local/private/api/knm/820700/links", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t332.inf", 
		"Mode=HTML", 
		LAST);

	web_url("820700", 
		"URL=http://private.proverki.local/private/api/knm/820700", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/820700", 
		"Snapshot=t333.inf", 
		"Mode=HTML", 
		LAST);

	web_url("organizations_13", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations?withDistrict=true", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/new", 
		"Snapshot=t334.inf", 
		"Mode=HTML", 
		LAST);

	web_url("history", 
		"URL=http://private.proverki.local/private/api/knm/820700/history", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/820700", 
		"Snapshot=t336.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://private.proverki.local");

	web_custom_request("820700_2", 
		"URL=http://private.proverki.local/erknm-editors/api/knm/820700", 
		"Method=PUT", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knm/820700", 
		"Snapshot=t337.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("logout_3", 
		"URL=http://private.proverki.local/public/auth/authenticator/api/internalauth/logout", 
		"Method=DELETE", 
		"Resource=0", 
		"Referer=http://private.proverki.local/private/knm/820700", 
		"Snapshot=t338.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
