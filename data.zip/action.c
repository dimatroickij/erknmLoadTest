Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_set_user("prosecutor", 
		lr_unmask("62175d13c56f84d167e44990"), 
		"private.proverki.local:80");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("private.proverki.local", 
		"URL=http://private.proverki.local/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/private/static/js/2.6caa3188.chunk.js", ENDITEM, 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_url("98.0.1108.56", 
		"URL=https://config.edge.skype.com/config/v1/Edge/98.0.1108.56?clientId=-8441220140427578937&agents=EdgeConfig%2CEdgeDomainActions%2CEdgeFirstRunConfig%2CEdgeDataConfig&osname=win&client=edge&channel=stable&scpfull=0&scpguard=0&scpfre=0&scpver=&osarch=x86_64&osver=10.0.18363&osedition=professional&wu=1&devicefamily=desktop&uma=0&mngd=1&installdate=1609926792", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("pglt-edgeChromium-ntp=2083; DOMAIN=ntp.msn.com");

	web_add_cookie("sptmarket=ru-RU|RU|ru|ru-ru|ru-ru|ru; DOMAIN=ntp.msn.com");

	web_add_cookie("sptmarket=ru||ru|ru-ru|ru-ru|ru; DOMAIN=ntp.msn.com");

	web_add_cookie("MicrosoftApplicationsTelemetryDeviceId=60f74110-4a5c-4df7-94c0-9d6be565c106; DOMAIN=ntp.msn.com");

	web_add_cookie("APP_ANON=A=9978A347D1879FAC85688C2FFFFFFFFF; DOMAIN=ntp.msn.com");

	web_add_cookie("aace=%7b%22child%22%3a0%7d; DOMAIN=ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"98\", \"Microsoft Edge\";v=\"98\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("ntp", 
		"URL=https://ntp.msn.com/edge/ntp?locale=ru&title=%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B2%D0%BA%D0%BB%D0%B0%D0%B4%D0%BA%D0%B0&dsp=0&sp=%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81&prerender=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../bundles/v1/edgeChromium/latest/web-worker.41f00c5f302731460ad4.js", "Referer=https://ntp.msn.com/edge/ntp?locale=ru&title=%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B2%D0%BA%D0%BB%D0%B0%D0%B4%D0%BA%D0%B0&dsp=0&sp=%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81&prerender=1", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	lr_think_time(9);

	web_url("config", 
		"URL=https://ntp.msn.com/resolver/api/resolve/v3/config/?expType=AppConfig&expInstance=default&apptype=edgeChromium&v=20220218.493&targetScope={%22audienceMode%22:%22adult%22,%22browser%22:{%22browserType%22:%22edgeChromium%22,%22version%22:%2298%22,%22ismobile%22:%22false%22},%22deviceFormFactor%22:%22desktop%22,%22domain%22:%22ntp.msn.com%22,%22locale%22:{%22content%22:{%22language%22:%22ru%22,%22market%22:%22ru%22},%22display%22:{%22language%22:%22ru%22,%22market%22:%22ru%22}},%22os%22"
		":%22windows%22,%22platform%22:%22web%22,%22pageType%22:%22ntp%22,%22pageExperiments%22:[%22prg-wpo-tsclpinf%22]}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/bundles/v1/edgeChromium/latest/web-worker.41f00c5f302731460ad4.js", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_url("20220218.493.json", 
		"URL=https://assets.msn.com/periconfigs/feature-manifests/edgechromium/20220218.493.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ntp.msn.com/edge/ntp/service-worker.js", "Referer=https://ntp.msn.com/edge/ntp/service-worker.js", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("20220218.493.json_2", 
		"URL=https://assets.msn.com/periconfigs/loc-manifests/edgechromium/20220218.493.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://private.proverki.local/private/static/media/loader.76756433.gif", "Referer=http://private.proverki.local/private/auth", ENDITEM, 
		"Url=http://private.proverki.local/private/static/media/FiraSans-Regular.34239e5e.woff2", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=http://private.proverki.local/private/static/media/FiraSans-Light.4e01567d.woff2", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=/bundles/v1/edgeChromium/latest/0.db33beb6fac799ea9b20.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_url("f4484a52f96293af07702b096389c42f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/appconfig/default/index.json/f4484a52f96293af07702b096389c42f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_auto_header("Origin", 
		"http://private.proverki.local");

	lr_think_time(4);

	web_custom_request("auth", 
		"URL=http://private.proverki.local/public/auth/authenticator/api/internalauth/auth?loaderKey=default", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/auth", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	lr_think_time(4);

	web_url("e775828d82978d77d8a66f407cbe63a8.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/appconfig/default/config.json/e775828d82978d77d8a66f407cbe63a8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bundles/v1/edgeChromium/latest/1.fa0c143d294b2f7fc9f1.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_url("eb658d6806a5aafe148cfa63082cc99a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/index.json/eb658d6806a5aafe148cfa63082cc99a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("fac769e3df0c3495266df41e8e4d4b67.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/edgechromiumpagewc/default/index.json/fac769e3df0c3495266df41e8e4d4b67.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_url("extendedprofile", 
		"URL=http://private.proverki.local/public/api/access-manager/api/users/current/extendedprofile", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/auth", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_url("9a0eddf5ba7804d0fb9859cdaa14bc54.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_ru-ru.json/9a0eddf5ba7804d0fb9859cdaa14bc54.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("2d593b46f0903e3d33d0584a55ab5649.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config.json/2d593b46f0903e3d33d0584a55ab5649.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("d2fc68f85315d05b9cb6e36e2289a065.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_adult.json/d2fc68f85315d05b9cb6e36e2289a065.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("91654baf0089db5dd4d0c05f92148603.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_ru-ru_adult.json/91654baf0089db5dd4d0c05f92148603.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("8f7a43a9326c2b9d8dd092e41135f4e1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_adult_windows.json/8f7a43a9326c2b9d8dd092e41135f4e1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("6fc32719fbf6cf5e068feb5afb38549f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_prg-wpo-tsclpinf.json/6fc32719fbf6cf5e068feb5afb38549f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_url("a7e4687e3ac11cac1ba04d4517feec7b.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/edgechromiumpagewc/default/config_ru.json/a7e4687e3ac11cac1ba04d4517feec7b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bundles/v1/edgeChromium/latest/10.2aafffc9ddf7caf0bf93.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_url("3b178c67f28066d38c6b505be61f499a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/telemetrydataedgechromium/default/index.json/3b178c67f28066d38c6b505be61f499a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_url("85f18de8b25b736d511ebfccb6f0f35b.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/irisdata/default/index.json/85f18de8b25b736d511ebfccb6f0f35b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0ba4590a841ba960259ff23aa6c48357.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/smartlistshareddata/default/index.json/0ba4590a841ba960259ff23aa6c48357.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_url("ae312c156b9f8361fc0b5d46204b924f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/telemetrydata/default/index.json/ae312c156b9f8361fc0b5d46204b924f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("e0b73f54e55df4315e2af3e35ab705e5.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/experiencetrackeredgenextdata/default/index.json/e0b73f54e55df4315e2af3e35ab705e5.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("1d5c09188bd29d0bdf799617f79b854f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/chromiumpagesettings/default/index.json/1d5c09188bd29d0bdf799617f79b854f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_url("baa74fb4e0a23689d40cf9b5362a4b8e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/backgroundimagewc/default/index.json/baa74fb4e0a23689d40cf9b5362a4b8e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("e28f3538f030c58a157e6a822b7eb69a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topicdata/default/index.json/e28f3538f030c58a157e6a822b7eb69a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_url("c2fdb407a10e8fc4dc9d6399641df548.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/backgroundimagewc/default/index.json/c2fdb407a10e8fc4dc9d6399641df548.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_url("ce326d2f243f400dab521edd6e22ba75.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/breakingnewswc/default/index.json/ce326d2f243f400dab521edd6e22ba75.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_url("bc0c4fa235f123ac0a32dd3dd5989438.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/cardactionwc/default/index.json/bc0c4fa235f123ac0a32dd3dd5989438.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0b55513f66729c8c17cb8d781459957c.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/cardactionwc/default/index.json/0b55513f66729c8c17cb8d781459957c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_url("6575eb349bdaaf2c8ad969e349574257.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/coachmarkwc/default/index.json/6575eb349bdaaf2c8ad969e349574257.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_url("5c5907d8b2b2162e80b3088c1039dea1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/conditionalbannerwc/default/index.json/5c5907d8b2b2162e80b3088c1039dea1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bundles/v1/edgeChromium/latest/11.11039ec1968811e25889.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_url("b68924b22f9838e5fef7778076e38293.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/devtools/default/index.json/b68924b22f9838e5fef7778076e38293.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

	web_url("e04e1f81c8f96b9348f9c86ff40d1ab9.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/pivotcontentwc/default/index.json/e04e1f81c8f96b9348f9c86ff40d1ab9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	web_url("85473f2b682f2230ea5384ae9e33f7a3.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/pivotcontentwc/default/index.json/85473f2b682f2230ea5384ae9e33f7a3.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0c191baf7ef120d5214a83363306fc67.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/pivotcontentwc/index_singlecolumnpivotcontent/index.json/0c191baf7ef120d5214a83363306fc67.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		LAST);

	web_url("dd9e170a6f56b5b582c2e852c6a9d6bf.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/searchboxedgenextwc/default/index.json/dd9e170a6f56b5b582c2e852c6a9d6bf.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		LAST);

	web_url("26467d28facc27642677111745d2ae25.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/searchboxedgenextwc/default/index.json/26467d28facc27642677111745d2ae25.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("X-AnchorMailbox", 
		"CID:7949298aebd9555a");

	web_url("profile", 
		"URL=https://substrate.office.com/profile/v1.0/me/profile", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_url("03a7b5086732d7978b45323c2e076505.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/index.json/03a7b5086732d7978b45323c2e076505.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		LAST);

	web_url("7bc23b0f973ead847ba9cbea437a7bb6.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/settingsdialogedgenextwc/default/index.json/7bc23b0f973ead847ba9cbea437a7bb6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://private.proverki.local/erknm-catalogs/api/public-portal-url", "Referer=http://private.proverki.local/private/auth", ENDITEM, 
		LAST);

	web_url("74463a4965edeec679cf7db3c5d76fa3.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/settingsdialogedgenextwc/default/index.json/74463a4965edeec679cf7db3c5d76fa3.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0e702ef5d69c4de6a9491adf2c4bf7b1.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/topsitesedgenextwc/default/index.json/0e702ef5d69c4de6a9491adf2c4bf7b1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		LAST);

	web_url("eaee621494ebc00ccd972234af10b047.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/wafflewc/default/index.json/eaee621494ebc00ccd972234af10b047.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);

	web_url("f3c5ff81cf9ec2d1b6e6b54c3a82ceeb.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/wafflewc/default/index.json/f3c5ff81cf9ec2d1b6e6b54c3a82ceeb.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		LAST);

	web_url("f183bc4db58fb33536a3153204eaf941.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/welcomegreetingwc/default/index.json/f183bc4db58fb33536a3153204eaf941.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		LAST);

	web_url("8e90cbf7e6faba0cb6b19b8414bb34b7.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/notificationbellwc/default/index.json/8e90cbf7e6faba0cb6b19b8414bb34b7.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		LAST);

	web_url("20dac0ba66cc1fcb379aa7cab7903f03.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/welcomegreetingwc/default/index.json/20dac0ba66cc1fcb379aa7cab7903f03.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		LAST);

	web_url("88fba2c11a1e97c2491f13a173b5558e.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/notificationbellwc/default/index.json/88fba2c11a1e97c2491f13a173b5558e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		LAST);

	web_url("9e7a4490f5cbe54c1c689c1ddfc4974d.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/searchhistoryedgenextwc/default/index.json/9e7a4490f5cbe54c1c689c1ddfc4974d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4bf1c018cbf565b6957c42c4e74649b9.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/searchhistoryedgenextwc/default/index.json/4bf1c018cbf565b6957c42c4e74649b9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		LAST);

	web_url("a61a8112a0ad0f5ff8fe4484389d6270.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/feednavigationheader/default/index.json/a61a8112a0ad0f5ff8fe4484389d6270.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t54.inf", 
		"Mode=HTML", 
		LAST);

	web_url("b76da2f5c0e421a9b2fedf25dc11a393.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/outlookemailpreview/default/index.json/b76da2f5c0e421a9b2fedf25dc11a393.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		LAST);

	web_url("444b4acc233517a5bab3fbd48bcf39a0.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/outlookemailpreview/default/index.json/444b4acc233517a5bab3fbd48bcf39a0.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/telemetrydataedgechromium/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_url("roles", 
		"URL=http://private.proverki.local/erknm-catalogs/api/admin/news/roles", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		LAST);

	web_url("published", 
		"URL=http://private.proverki.local/erknm-catalogs/api/news/published?type=ANNOUNCEMENT&order=published,desc;", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("status-info-read", 
		"URL=http://private.proverki.local/erknm-catalogs/api/signature/user/status-info-read", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_url("1b075e61ef08da5a4d1ac297e737afe1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/irisdata/default/config_adult.json/1b075e61ef08da5a4d1ac297e737afe1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		LAST);

	web_url("8a388da385ce143720232e29028511fe.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/irisdata/default/config.json/8a388da385ce143720232e29028511fe.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_2", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/smartlistshareddata/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_3", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/telemetrydata/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		LAST);

	web_url("db4ab5feb7e54de8c3d1e35237632737.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/experiencetrackeredgenextdata/default/config.json/db4ab5feb7e54de8c3d1e35237632737.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		LAST);

	web_url("a0aeddead28162640c4e66a0b772a1d6.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/experiencetrackeredgenextdata/default/config_adult.json/a0aeddead28162640c4e66a0b772a1d6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t66.inf", 
		"Mode=HTML", 
		LAST);

	web_url("dd7c57437d6bc9d8bac41c8dd644a538.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/chromiumpagesettings/default/config.json/dd7c57437d6bc9d8bac41c8dd644a538.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_4", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topicdata/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t68.inf", 
		"Mode=HTML", 
		LAST);

	web_url("6f7f956c296b19e3322d4f03920c2509.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/backgroundimagewc/default/config_ru.json/6f7f956c296b19e3322d4f03920c2509.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		LAST);

	web_url("081b66d2a6a17293e15f8ecae65bbf50.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/backgroundimagewc/default/config.json/081b66d2a6a17293e15f8ecae65bbf50.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t70.inf", 
		"Mode=HTML", 
		LAST);

	web_url("fee8392d3d0bc99dff496a10a53eafd5.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/chromiumpagesettings/default/config_adult.json/fee8392d3d0bc99dff496a10a53eafd5.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t71.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_5", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/breakingnewswc/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t72.inf", 
		"Mode=HTML", 
		LAST);

	web_url("9c36390e79edd93b6e4a4bcd7a8372b1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/breakingnewswc/default/config_ru-ru.json/9c36390e79edd93b6e4a4bcd7a8372b1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t73.inf", 
		"Mode=HTML", 
		LAST);

	web_url("fe73422cc1a43c40c8d54158d2d14df7.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/cardactionwc/default/config.json/fe73422cc1a43c40c8d54158d2d14df7.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t74.inf", 
		"Mode=HTML", 
		LAST);

	web_url("571274593bd8b6ea3abd4a4ae52c59a3.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/coachmarkwc/default/config.json/571274593bd8b6ea3abd4a4ae52c59a3.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t75.inf", 
		"Mode=HTML", 
		LAST);

	web_url("e56e6b80593610ad622099a3355d2520.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/cardactionwc/default/config_ru.json/e56e6b80593610ad622099a3355d2520.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t76.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_6", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/conditionalbannerwc/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		LAST);

	web_url("2308202ae88d3ae3a15a11a9dbb0a2c5.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/feednavigationheader/default/index.json/2308202ae88d3ae3a15a11a9dbb0a2c5.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t78.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_url("organizations", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/auth", 
		"Snapshot=t79.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/12.5462c3a60a98d3c4e025.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_url("3c53240893eb894dcaa52ac8bc6e2dc3.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/devtools/default/config.json/3c53240893eb894dcaa52ac8bc6e2dc3.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t80.inf", 
		"Mode=HTML", 
		LAST);

	web_url("63448d938a40d589762e293b37b2149c.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/pivotcontentwc/index_singlecolumnpivotcontent/config.json/63448d938a40d589762e293b37b2149c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_7", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/pivotcontentwc/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t82.inf", 
		"Mode=HTML", 
		LAST);

	web_url("cfedf7faeb7cf62ec534269635f2c708.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/searchboxedgenextwc/default/config_ntp.json/cfedf7faeb7cf62ec534269635f2c708.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		LAST);

	web_url("afb81468e8775ee8cf6896fae20deaa5.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/searchboxedgenextwc/default/config.json/afb81468e8775ee8cf6896fae20deaa5.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t84.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_url("organizations_2", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_url("b8c1dac36fe998430aa72d70f273466d.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/searchboxedgenextwc/default/config_ru.json/b8c1dac36fe998430aa72d70f273466d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t86.inf", 
		"Mode=HTML", 
		LAST);

	web_url("f128ce8cae434b59f76ff80edc6a1dac.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/settingsdialogedgenextwc/default/config.json/f128ce8cae434b59f76ff80edc6a1dac.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t87.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_custom_request("check-notification", 
		"URL=http://private.proverki.local/erknm-knm/api/knm-plan/check-notification", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk/info", 
		"Snapshot=t88.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_url("4ac595d62bd8584b86dacecae3b951f8.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/settingsdialogedgenextwc/default/config_adult.json/4ac595d62bd8584b86dacecae3b951f8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t89.inf", 
		"Mode=HTML", 
		LAST);

	web_url("aadd3b61227344be5e970ea9471a7cff.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/settingsdialogedgenextwc/default/config_ru.json/aadd3b61227344be5e970ea9471a7cff.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t90.inf", 
		"Mode=HTML", 
		LAST);

	web_url("9d92976d5034c793842cdbea9fff3030.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config.json/9d92976d5034c793842cdbea9fff3030.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t91.inf", 
		"Mode=HTML", 
		LAST);

	web_url("03c4bd43dd3db88ba636fbe83e008e2b.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config_ru-ru.json/03c4bd43dd3db88ba636fbe83e008e2b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t92.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://private.proverki.local/private/static/media/close.4a519fb6.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_url("59ec862d217368d460a2705aef2bc160.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config_adult.json/59ec862d217368d460a2705aef2bc160.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t93.inf", 
		"Mode=HTML", 
		LAST);

	web_url("14c0fbe432220fbb472e159c6e0bcf68.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config_adult_windows.json/14c0fbe432220fbb472e159c6e0bcf68.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t94.inf", 
		"Mode=HTML", 
		LAST);

	web_url("71d45b69c6060ad14b538b41fb4109c7.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/topsitesedgenextwc/default/config_ru.json/71d45b69c6060ad14b538b41fb4109c7.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t95.inf", 
		"Mode=HTML", 
		LAST);

	web_url("e86aac6be73fdbf2d71c365de67b02f6.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/wafflewc/default/config.json/e86aac6be73fdbf2d71c365de67b02f6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t96.inf", 
		"Mode=HTML", 
		LAST);

	web_url("cd4b87275cf14c5e82030eb1027fa1b8.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/welcomegreetingwc/default/config.json/cd4b87275cf14c5e82030eb1027fa1b8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t97.inf", 
		"Mode=HTML", 
		LAST);

	web_url("9530b94a0c3afc183c054742e1c58197.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/welcomegreetingwc/default/config_ru.json/9530b94a0c3afc183c054742e1c58197.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t98.inf", 
		"Mode=HTML", 
		LAST);

	web_url("7b1dc0170ae63120c83fd77bce86e63f.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/wafflewc/default/config_ru.json/7b1dc0170ae63120c83fd77bce86e63f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t99.inf", 
		"Mode=HTML", 
		LAST);

	web_url("f20fe086fe915c7fe7e3fc3102df61f7.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/notificationbellwc/default/config.json/f20fe086fe915c7fe7e3fc3102df61f7.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t100.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_8", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/notificationbellwc/default/config_adult.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t101.inf", 
		"Mode=HTML", 
		LAST);

	web_url("5f76a6a9e459d0b57a0c253c75402d97.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/notificationbellwc/default/config_ru-ru_adult.json/5f76a6a9e459d0b57a0c253c75402d97.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t102.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4ba9970e06067d39d36d3210e282ee35.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/notificationbellwc/default/config_ru.json/4ba9970e06067d39d36d3210e282ee35.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t103.inf", 
		"Mode=HTML", 
		LAST);

	web_url("c15d4312323662a599a2dd76d7111a37.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/searchhistoryedgenextwc/default/config.json/c15d4312323662a599a2dd76d7111a37.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t104.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0cc4c2d83b485043c9831a86ae889acd.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/searchhistoryedgenextwc/default/config_adult.json/0cc4c2d83b485043c9831a86ae889acd.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t105.inf", 
		"Mode=HTML", 
		LAST);

	web_url("b6615111def0c75bc7451a38ed4ace3b.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/searchhistoryedgenextwc/default/config_ru.json/b6615111def0c75bc7451a38ed4ace3b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t106.inf", 
		"Mode=HTML", 
		LAST);

	web_url("e983d1d6e6c9a6734720dbbf44129649.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/outlookemailpreview/default/config.json/e983d1d6e6c9a6734720dbbf44129649.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t107.inf", 
		"Mode=HTML", 
		LAST);

	web_url("8e3d2e9a30ae545568be12052599bbc9.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/outlookemailpreview/default/config_ru.json/8e3d2e9a30ae545568be12052599bbc9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t108.inf", 
		"Mode=HTML", 
		LAST);

	web_url("7e86d9c88f44603da908c46db7fb59e3.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/coachmarkdata/default/index.json/7e86d9c88f44603da908c46db7fb59e3.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t109.inf", 
		"Mode=HTML", 
		LAST);

	web_url("1e819da18c6761fade504018c332bee8.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/feednavigationheader/default/config.json/1e819da18c6761fade504018c332bee8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t110.inf", 
		"Mode=HTML", 
		LAST);

	web_url("6b539a4716d8cea73885998bef29736b.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/interestswc/default/index.json/6b539a4716d8cea73885998bef29736b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t111.inf", 
		"Mode=HTML", 
		LAST);

	web_url("e8bf4d70cb5160a8ca6fca07ff6a03c9.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/interestswc/default/index.json/e8bf4d70cb5160a8ca6fca07ff6a03c9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		LAST);

	web_url("e8f7e014ea8c4c5ea55d4a9543ad2be9.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/feednavigationheader/default/config_ru-ru.json/e8f7e014ea8c4c5ea55d4a9543ad2be9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t113.inf", 
		"Mode=HTML", 
		LAST);

	web_url("31391b207af8122b9cf350d7a194e12d.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/feednavigationheader/default/config_adult.json/31391b207af8122b9cf350d7a194e12d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		LAST);

	web_url("93d9046c3d0009b6600c37ea4c72b4cf.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/feednavigationheader/default/config_ru.json/93d9046c3d0009b6600c37ea4c72b4cf.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t115.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bundles/v1/edgeChromium/latest/13.eb6686e485e3c4a9949d.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_url("e92b379f8b22a97d5a12c92df4c64867.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/voicesearchwc/default/index.json/e92b379f8b22a97d5a12c92df4c64867.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t116.inf", 
		"Mode=HTML", 
		LAST);

	web_url("c9e38c345a819ae280f24c8148fdbb62.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weatherdata/_edge-index-weatherdataconnectorindex-bbwm2bo/index.json/c9e38c345a819ae280f24c8148fdbb62.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t117.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_9", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/coachmarkdata/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t118.inf", 
		"Mode=HTML", 
		LAST);

	web_url("e737ba9d5edee3460c4146239489337f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/interestswc/default/config.json/e737ba9d5edee3460c4146239489337f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t119.inf", 
		"Mode=HTML", 
		LAST);

	web_url("25498001b44d4952415bde431cf9ec2a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/interestswc/default/config_ru.json/25498001b44d4952415bde431cf9ec2a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t120.inf", 
		"Mode=HTML", 
		LAST);

	web_url("90eff1e279314deaff340dbb72400dc0.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/interestswc/default/config_ru-ru.json/90eff1e279314deaff340dbb72400dc0.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t121.inf", 
		"Mode=HTML", 
		LAST);

	web_url("6a6dfc068a25843a3123a29af2585a54.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/interestswc/default/config_adult.json/6a6dfc068a25843a3123a29af2585a54.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t122.inf", 
		"Mode=HTML", 
		LAST);

	web_url("72b3c57feefada933e04d61c14e68923.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/interestswc/default/config_ru.json/72b3c57feefada933e04d61c14e68923.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t123.inf", 
		"Mode=HTML", 
		LAST);

	web_url("1b614b16363a290d34841d7e243c5395.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/feedtogglewc/default/index.json/1b614b16363a290d34841d7e243c5395.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t124.inf", 
		"Mode=HTML", 
		LAST);

	web_url("83f7975d557c8659c27b6a6243f908e6.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/layouttoggle/default/index.json/83f7975d557c8659c27b6a6243f908e6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t125.inf", 
		"Mode=HTML", 
		LAST);

	web_url("98e788f5cfba80f8617b39b003ac8f61.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/feedtogglewc/default/index.json/98e788f5cfba80f8617b39b003ac8f61.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t126.inf", 
		"Mode=HTML", 
		LAST);

	web_url("2936839708ac43c41e0098740fca5eb0.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/xfeedwc/default/index.json/2936839708ac43c41e0098740fca5eb0.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t127.inf", 
		"Mode=HTML", 
		LAST);

	web_url("72bb76169763f835a4ab73841bb6d502.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/xfeedwc/default/index.json/72bb76169763f835a4ab73841bb6d502.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t128.inf", 
		"Mode=HTML", 
		LAST);

	web_url("3921591cbbd23fb8c24458c0a523fae9.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/desktopfeededgenextwc/default/index.json/3921591cbbd23fb8c24458c0a523fae9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t129.inf", 
		"Mode=HTML", 
		LAST);

	web_url("f9ce1bc9c30067b231ed516da84ee854.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/desktopfeededgenextwc/default/index.json/f9ce1bc9c30067b231ed516da84ee854.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t130.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bundles/v1/edgeChromium/latest/14.3f0425cbf5aa677553e4.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_url("ca58ca1eddc593761d0852c61cb36c69.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weatherdata/_edge-index-weatherdataconnectorindex-bbwm2bo/config.json/ca58ca1eddc593761d0852c61cb36c69.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t131.inf", 
		"Mode=HTML", 
		LAST);

	web_url("d101ec5baa0096ace9db3f481fd98cf4.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shared/msn-ns/contentpreview/default/index.json/d101ec5baa0096ace9db3f481fd98cf4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t132.inf", 
		"Mode=HTML", 
		LAST);

	web_url("f6d381f16fefc5dcfb54b3bbfb9986a4.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/contentpreview/default/index.json/f6d381f16fefc5dcfb54b3bbfb9986a4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t133.inf", 
		"Mode=HTML", 
		LAST);

	web_url("bd588dfaa1f085a4b831ce5a72462bb4.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/toastwc/default/index.json/bd588dfaa1f085a4b831ce5a72462bb4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t134.inf", 
		"Mode=HTML", 
		LAST);

	web_url("285ca7895c79d3c37dc2d827b046157d.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/toastwc/default/index.json/285ca7895c79d3c37dc2d827b046157d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t135.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_10", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/layouttoggle/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t136.inf", 
		"Mode=HTML", 
		LAST);

	web_url("36d42e7e614b0105e0a1431ed242c178.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/feedtogglewc/default/config.json/36d42e7e614b0105e0a1431ed242c178.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t137.inf", 
		"Mode=HTML", 
		LAST);

	web_url("dfecec4a861a62313963ed09eeec5726.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/feedtogglewc/default/config_ru-ru_adult.json/dfecec4a861a62313963ed09eeec5726.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t138.inf", 
		"Mode=HTML", 
		LAST);

	web_url("98c9f1c4605b39ea85e191d6b0f2adaa.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/voicesearchwc/default/index.json/98c9f1c4605b39ea85e191d6b0f2adaa.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t139.inf", 
		"Mode=HTML", 
		LAST);

	web_url("390e42bc22654a65fdd2ee97f46a6d6d.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/feedtogglewc/default/config_ru.json/390e42bc22654a65fdd2ee97f46a6d6d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t140.inf", 
		"Mode=HTML", 
		LAST);

	web_url("fb2cc7e3deaa6f0a2cb9ca6ce83b9778.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/xfeedwc/default/config.json/fb2cc7e3deaa6f0a2cb9ca6ce83b9778.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t141.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0a90058a5733eff049c77347d6bf66b2.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/xfeedwc/default/config_ru.json/0a90058a5733eff049c77347d6bf66b2.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t142.inf", 
		"Mode=HTML", 
		LAST);

	web_url("82fd2508f5e06d752ca92e340978f843.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/desktopfeededgenextwc/default/config.json/82fd2508f5e06d752ca92e340978f843.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t143.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0242d7c6876f2d8d8756bb5c477d448a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/desktopfeededgenextwc/default/config_ru-ru.json/0242d7c6876f2d8d8756bb5c477d448a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t144.inf", 
		"Mode=HTML", 
		LAST);

	web_url("31e8bd1b605d53d616c47b1a4f5d8dd1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/desktopfeededgenextwc/default/config_ru-ru_adult.json/31e8bd1b605d53d616c47b1a4f5d8dd1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t145.inf", 
		"Mode=HTML", 
		LAST);

	web_url("2fa813fd8a0e7bfa99f9705019fa959d.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/desktopfeededgenextwc/default/config_ru.json/2fa813fd8a0e7bfa99f9705019fa959d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t146.inf", 
		"Mode=HTML", 
		LAST);

	web_url("bf1b91052233f9380ff1778ddf7844e5.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shared/msn-ns/contentpreview/default/config.json/bf1b91052233f9380ff1778ddf7844e5.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t147.inf", 
		"Mode=HTML", 
		LAST);

	web_url("24b12cb5ae48607501e711b5953ea28d.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/desktopfeededgenextwc/default/config_adult.json/24b12cb5ae48607501e711b5953ea28d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t148.inf", 
		"Mode=HTML", 
		LAST);

	web_url("164465ba498f26aea245436e0845b989.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/contentpreview/default/config_ru.json/164465ba498f26aea245436e0845b989.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t149.inf", 
		"Mode=HTML", 
		LAST);

	web_url("808f0c5b274d61c85b3336fd675b8194.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/toastwc/default/config.json/808f0c5b274d61c85b3336fd675b8194.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t150.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0d43b9a1c5688d4f3ec043f610186a93.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/toastwc/default/config_ru.json/0d43b9a1c5688d4f3ec043f610186a93.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t151.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_11", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/voicesearchwc/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t152.inf", 
		"Mode=HTML", 
		LAST);

	web_url("b8e14068b0363d15ed23f39efde167e8.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/voicesearchwc/default/config_ru.json/b8e14068b0363d15ed23f39efde167e8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t153.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0fd0af51635f7576dc5306b86e40c079.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/bingvideocarousel/default/index.json/0fd0af51635f7576dc5306b86e40c079.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t154.inf", 
		"Mode=HTML", 
		LAST);

	web_url("674589d81d1b47cf7adb1571b610e48b.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/bingvideocarousel/default/index.json/674589d81d1b47cf7adb1571b610e48b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t155.inf", 
		"Mode=HTML", 
		LAST);

	web_url("eaa773dc4c2304e669e7a69f8d15c637.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/coldstartwc/default/index.json/eaa773dc4c2304e669e7a69f8d15c637.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t156.inf", 
		"Mode=HTML", 
		LAST);

	web_url("5c852c7f06928f6dfc03c4ff46ec180e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/socialbarwc/default/index.json/5c852c7f06928f6dfc03c4ff46ec180e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t157.inf", 
		"Mode=HTML", 
		LAST);

	web_url("425cb461cc20824c0e6628cd6b9f2513.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/socialbarwc/default/index.json/425cb461cc20824c0e6628cd6b9f2513.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t158.inf", 
		"Mode=HTML", 
		LAST);

	web_url("3edf94c7d6ceff167aee80dc8d592128.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/coldstartwc/default/index.json/3edf94c7d6ceff167aee80dc8d592128.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t159.inf", 
		"Mode=HTML", 
		LAST);

	web_url("34ad37c4985372ec212277feb8bd0201.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weathercardwc/default/index.json/34ad37c4985372ec212277feb8bd0201.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t160.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bundles/v1/edgeChromium/latest/15.65879f3c455f09a607d2.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_url("8d421d475c61e302b67613e69f7e36de.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/weathercardwc/default/index.json/8d421d475c61e302b67613e69f7e36de.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t161.inf", 
		"Mode=HTML", 
		LAST);

	web_url("ed24e35d3b6c867e5b0e73a7cf9bddd4.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/moneyinfocardwc/default/index.json/ed24e35d3b6c867e5b0e73a7cf9bddd4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t162.inf", 
		"Mode=HTML", 
		LAST);

	web_url("320d5834cd46d99f0837fa2225a6650b.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shoppingcardwc/index_dailydeals/index.json/320d5834cd46d99f0837fa2225a6650b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t163.inf", 
		"Mode=HTML", 
		LAST);

	web_url("97b19d6d2d57b519ada2b2525b38fd8d.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/moneyinfocardwc/default/index.json/97b19d6d2d57b519ada2b2525b38fd8d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t164.inf", 
		"Mode=HTML", 
		LAST);

	web_url("8fe4bda8e094905bcaee5a0f573512c9.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/shoppingcardwc/default/index.json/8fe4bda8e094905bcaee5a0f573512c9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t165.inf", 
		"Mode=HTML", 
		LAST);

	web_url("b3805f6c1b824621b552e8e774fdde51.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shoppingcardwc/index_edge/index.json/b3805f6c1b824621b552e8e774fdde51.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t166.inf", 
		"Mode=HTML", 
		LAST);

	web_url("7af71be9cb421c01ab959aa6cfb2ec8f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shoppingcardwc/index_shoppingcarouseltrendingproducts/index.json/7af71be9cb421c01ab959aa6cfb2ec8f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t167.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0c7f7e6909ed80c8f7b700ab2b14528c.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/sportscardwc/default/index.json/0c7f7e6909ed80c8f7b700ab2b14528c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t168.inf", 
		"Mode=HTML", 
		LAST);

	web_url("be73badf99da2e67193cfb9e063af590.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/sportscardwc/default/index.json/be73badf99da2e67193cfb9e063af590.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t169.inf", 
		"Mode=HTML", 
		LAST);

	web_url("d13dc3d7e769db32aaff8508683477a6.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/sportsolympiccardwc/default/index.json/d13dc3d7e769db32aaff8508683477a6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t170.inf", 
		"Mode=HTML", 
		LAST);

	web_url("3ca4b4ac585ec301f4a1d52c93b21f91.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/sportsolympiccardwc/default/index.json/3ca4b4ac585ec301f4a1d52c93b21f91.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t171.inf", 
		"Mode=HTML", 
		LAST);

	web_url("81d086bb3dc1a406b49959e15b324f50.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/nativeadwc/default/index.json/81d086bb3dc1a406b49959e15b324f50.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t172.inf", 
		"Mode=HTML", 
		LAST);

	web_url("299be354bbbfab9825e52e21856fc553.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/nativeadwc/default/index.json/299be354bbbfab9825e52e21856fc553.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t173.inf", 
		"Mode=HTML", 
		LAST);

	web_url("567cd7602773d24751f5ec77ed63ac0e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/trafficcardwc/default/index.json/567cd7602773d24751f5ec77ed63ac0e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t174.inf", 
		"Mode=HTML", 
		LAST);

	web_url("a4151cc6150edfccc5f4e769e9fe7dce.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/trafficcardwc/default/index.json/a4151cc6150edfccc5f4e769e9fe7dce.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t175.inf", 
		"Mode=HTML", 
		LAST);

	web_url("f5ad46367aca858a6ada0d4bfa818813.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/binghealthfitnesscard/default/index.json/f5ad46367aca858a6ada0d4bfa818813.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t176.inf", 
		"Mode=HTML", 
		LAST);

	web_url("c1aa8c8d9e2b17398632208d3f5c81be.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/binghealthfitnesscard/default/index.json/c1aa8c8d9e2b17398632208d3f5c81be.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t177.inf", 
		"Mode=HTML", 
		LAST);

	web_url("5f7959b0eb6b41f38901c7fbd85bca11.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/selectcarousel/default/index.json/5f7959b0eb6b41f38901c7fbd85bca11.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t178.inf", 
		"Mode=HTML", 
		LAST);

	web_url("6547e39430196249ccd563b2e00f3ddc.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/pillwc/default/index.json/6547e39430196249ccd563b2e00f3ddc.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t179.inf", 
		"Mode=HTML", 
		LAST);

	web_url("d629ea7e76147190c37f9077c850f450.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/pillwc/default/index.json/d629ea7e76147190c37f9077c850f450.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t180.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0be9cfbdec82cfcbd9a431aca792edf6.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/selectcarousel/default/index.json/0be9cfbdec82cfcbd9a431aca792edf6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t181.inf", 
		"Mode=HTML", 
		LAST);

	web_url("898323465697c2bd41cf806b3108c413.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/socialbarwc/default/config.json/898323465697c2bd41cf806b3108c413.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t182.inf", 
		"Mode=HTML", 
		LAST);

	web_url("fe6fa976366eba24634bb6d7f382535a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/socialbarwc/default/config_adult.json/fe6fa976366eba24634bb6d7f382535a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t183.inf", 
		"Mode=HTML", 
		LAST);

	web_url("34aa887a7c9bb4907f193d2dadf36f38.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/coldstartwc/default/config.json/34aa887a7c9bb4907f193d2dadf36f38.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t184.inf", 
		"Mode=HTML", 
		LAST);

	web_url("21e3240aab0867e42a22f5b9f5750155.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/bingvideocarousel/default/config_ru.json/21e3240aab0867e42a22f5b9f5750155.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t185.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0098f5dbbf2702119ff662ec6869655f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/bingvideocarousel/default/config.json/0098f5dbbf2702119ff662ec6869655f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t186.inf", 
		"Mode=HTML", 
		LAST);

	web_url("36e73eed377028e7f1cb0ec70803c4b0.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/socialbarwc/default/config_ru.json/36e73eed377028e7f1cb0ec70803c4b0.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t187.inf", 
		"Mode=HTML", 
		LAST);

	web_url("a77562df3f505f4a81ceb04156d5db6e.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/coldstartwc/default/config_ru.json/a77562df3f505f4a81ceb04156d5db6e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t188.inf", 
		"Mode=HTML", 
		LAST);

	web_url("a32f36be00ee0c13dbdb51f39bfc067c.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weathercardwc/default/config.json/a32f36be00ee0c13dbdb51f39bfc067c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t189.inf", 
		"Mode=HTML", 
		LAST);

	web_url("99934d026a52ae6ccbef3fa750b29154.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/weathercardwc/default/config_ru.json/99934d026a52ae6ccbef3fa750b29154.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t190.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bundles/v1/edgeChromium/latest/16.984a39387e933d138325.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_url("ebdd51777dcfdae86653419b7cf0530c.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/moneyinfocardwc/default/config.json/ebdd51777dcfdae86653419b7cf0530c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t191.inf", 
		"Mode=HTML", 
		LAST);

	web_url("649e21760aba9221e5d8674a18aa89c8.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/moneyinfocardwc/default/config_ru.json/649e21760aba9221e5d8674a18aa89c8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t192.inf", 
		"Mode=HTML", 
		LAST);

	web_url("9e2c9eeba6bb26f19dca7acff57d2b73.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/moneyinfocardwc/default/config_ru.json/9e2c9eeba6bb26f19dca7acff57d2b73.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t193.inf", 
		"Mode=HTML", 
		LAST);

	web_url("66f8d9daaa3afc6a42f2d29d050ebfb7.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shoppingcardwc/index_dailydeals/config.json/66f8d9daaa3afc6a42f2d29d050ebfb7.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t194.inf", 
		"Mode=HTML", 
		LAST);

	web_url("6914bc8a3cafae402cdc72778460d612.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/shoppingcardwc/default/config_ru.json/6914bc8a3cafae402cdc72778460d612.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t195.inf", 
		"Mode=HTML", 
		LAST);

	web_url("55d4fff8170a79cd17c5985029cb528e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shoppingcardwc/index_edge/config.json/55d4fff8170a79cd17c5985029cb528e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t196.inf", 
		"Mode=HTML", 
		LAST);

	web_url("13e65bc2dee38d4752ee249eb1e1157e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shoppingcardwc/index_shoppingcarouseltrendingproducts/config.json/13e65bc2dee38d4752ee249eb1e1157e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t197.inf", 
		"Mode=HTML", 
		LAST);

	web_url("0aae99e4084afff4e4c23bed237c7c63.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/sportscardwc/default/config.json/0aae99e4084afff4e4c23bed237c7c63.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t198.inf", 
		"Mode=HTML", 
		LAST);

	web_url("565d069f8140968765f3f31bd265e341.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/sportscardwc/default/config_ru.json/565d069f8140968765f3f31bd265e341.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t199.inf", 
		"Mode=HTML", 
		LAST);

	web_url("b74a0d7b90729b90c11e38d6f2598f8f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/sportsolympiccardwc/default/config.json/b74a0d7b90729b90c11e38d6f2598f8f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t200.inf", 
		"Mode=HTML", 
		LAST);

	web_url("50bd8e21e2ad35ed6af25ba1fc095f38.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/sportsolympiccardwc/default/config_ru.json/50bd8e21e2ad35ed6af25ba1fc095f38.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t201.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_12", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/nativeadwc/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t202.inf", 
		"Mode=HTML", 
		LAST);

	web_url("d07e759c3f260f9bd052fab108b49b0c.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/nativeadwc/default/config_ru.json/d07e759c3f260f9bd052fab108b49b0c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t203.inf", 
		"Mode=HTML", 
		LAST);

	web_url("727c50e6a4cfdbaef272efd1f7326a4e.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/trafficcardwc/default/config_ru.json/727c50e6a4cfdbaef272efd1f7326a4e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t204.inf", 
		"Mode=HTML", 
		LAST);

	web_url("9c868bc2701ba6080d123b3c6bfcf7da.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/binghealthfitnesscard/default/config.json/9c868bc2701ba6080d123b3c6bfcf7da.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t205.inf", 
		"Mode=HTML", 
		LAST);

	web_url("a4e93ec489311869591fb80fcf59a78e.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/binghealthfitnesscard/default/config_ru.json/a4e93ec489311869591fb80fcf59a78e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t206.inf", 
		"Mode=HTML", 
		LAST);

	web_url("d8ffe967a10b05aa54f8ab09ea1fea7d.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/pillwc/default/config.json/d8ffe967a10b05aa54f8ab09ea1fea7d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t207.inf", 
		"Mode=HTML", 
		LAST);

	web_url("cbd6ca8213a5031d5b50c294263a5328.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/selectcarousel/default/config.json/cbd6ca8213a5031d5b50c294263a5328.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t208.inf", 
		"Mode=HTML", 
		LAST);

	web_url("94700792e6b087a229b235c1290330d8.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/pillwc/default/config_ru.json/94700792e6b087a229b235c1290330d8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t209.inf", 
		"Mode=HTML", 
		LAST);

	web_url("32cbccab652bf4e4a9a03a51057d47d3.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/trafficcardwc/default/config.json/32cbccab652bf4e4a9a03a51057d47d3.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t210.inf", 
		"Mode=HTML", 
		LAST);

	web_url("57cae9ded6cc508e7026c42d65fc8fd6.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/selectcarousel/default/config_adult.json/57cae9ded6cc508e7026c42d65fc8fd6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t211.inf", 
		"Mode=HTML", 
		LAST);

	web_url("ed0456b4ede934c70bd8579804d09b4d.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/selectcarousel/default/config_ru.json/ed0456b4ede934c70bd8579804d09b4d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t212.inf", 
		"Mode=HTML", 
		LAST);

	web_url("32c7af6b1c2e7da22185ee98b5bf9eea.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/reactionbreakdowndialog/default/index.json/32c7af6b1c2e7da22185ee98b5bf9eea.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t213.inf", 
		"Mode=HTML", 
		LAST);

	web_url("394c4d96ba1720a793f867794397664b.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/reactionbreakdowndialog/default/index.json/394c4d96ba1720a793f867794397664b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t214.inf", 
		"Mode=HTML", 
		LAST);

	web_url("71e74b2587c5aa70f636b2d9e601654f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/selectcarousel/default/config_ru-ru_adult.json/71e74b2587c5aa70f636b2d9e601654f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t215.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_13", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/reactionbreakdowndialog/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t216.inf", 
		"Mode=HTML", 
		LAST);

	web_url("fea02c25874863808801e38c61b4f9a9.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/reactionbreakdowndialog/default/config_ru.json/fea02c25874863808801e38c61b4f9a9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t217.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bundles/v1/edgeChromium/latest/17.69634bc32e93571d5e5b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=/bundles/v1/edgeChromium/latest/18.e349d8d6693ef33f27ad.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=/bundles/v1/edgeChromium/latest/19.6eb1d5f3afc67fb7ed0a.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=/bundles/v1/edgeChromium/latest/2.b5123af9fb3442b9ec31.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_add_cookie("sptmarket=ru-RU|RU|ru|ru-ru|ru-ru|ru; DOMAIN=api.msn.com");

	web_add_cookie("APP_ANON=A=9978A347D1879FAC85688C2FFFFFFFFF; DOMAIN=api.msn.com");

	web_add_cookie("aace=%7b%22child%22%3a0%7d; DOMAIN=api.msn.com");

	web_url("appanon", 
		"URL=https://api.msn.com/auth/cookie/appanon?scn=app_anon&ocid=Peregrine&apikey=0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t218.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/3.307a9a96f46dc7851675.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/4.36e28828d3c96822c8c9.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/5.a9d91d44dbec9d532b86.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/6.fab20aa09bb9e1e15f56.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/7.863a709b7211507682b6.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/8.fad855f4d477a628e5c5.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/9.ec011c5b29ef99a7d411.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/back-to-top-button.73f706fdfd98c08dbaf7.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/bingHealthCard.940008d550e292d1e454.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/bingHealthFitnessCard.62e795cac0a989bab30e.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/bingVideoCarousel.56e0e353bb68d4c529f5.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/breakingNewsWC.4ae18e4b8bcffe1e5524.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=http://private.proverki.local/private/static/media/info-italic.27ab16a9.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		"Url=http://private.proverki.local/private/static/media/settings.4811642b.svg", "Referer=http://private.proverki.local/private/static/css/main.881e09d5.chunk.css", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_custom_request("settings", 
		"URL=http://private.proverki.local/erknm-catalogs/api/settings", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t219.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/card-actions-wc.b1b57bb06ae16ed68a3a.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_url("published_2", 
		"URL=http://private.proverki.local/erknm-catalogs/api/news/published?type=ANNOUNCEMENT&order=published,desc;", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t220.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("schedule", 
		"URL=http://private.proverki.local/erknm-catalogs/api/settings/schedule", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t221.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/category-data-connector.f03bcf49d4d32a11041c.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"http://private.proverki.local");

	web_custom_request("find-indexes", 
		"URL=http://private.proverki.local/erknm-index/api/knm/find-indexes?page=0&size=50&order=erpId%2Casc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t222.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"version\":\"ERKNM\"}", 
		EXTRARES, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/clarity.b941fb13f6472d4ddb75.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/coachmark-wc.d2c4dcdcc6501c093c22.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/cold-start-wc.fb3c3d2db865efebae92.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/common.48aa0cddf25c134cfd3d.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/conditionalBannerWC.8246768fd052e4e44b66.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/content-group-card.aca5f5e3dafa6582c9da.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/content-group-card~traffic-card-wc.b8529d37725e78760652.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/daily-brief-wc.9f2f58b633dd4a45c84d.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/default-browser-reclaim-banner.7e512fb738ec4391f44f.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/desktop-feed-edgenext-wc.97c364a7cf3447cee2ac.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/desktop-feed-edgenext-wc~desktop-feed-single-column-wc~grid-view-feed~linear-view-feed.71c514ce12ff315b8ce0.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/desktop-feed-edgenext-wc~desktop-feed-single-column-wc~grid-view-feed~linear-view-feed~office-feed~r~08fb8431.d99cf680de9e2b4e1e0b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/desktop-feed-single-column-wc.d2272731ea2d84414da7.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/dev-tools.a5d5bd18cf7caa131a6b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/esports-card.6c4a6d2c802e049da705.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/esports-streams-card.70377d264cefedf6baf6.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/feed-navigation-header.475ea9d96066e52c5cbd.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/feed-toggle-wc.8aff5d25bc67b82f0d47.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/feedback-dialog.0cd8df0c80e1d27c045a.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/feedback.0daf180cf8a4334d1921.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/gaming-upcoming-card.99b79736f69bf92c543a.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/general-elections.ab60d76108fe80796e02.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/grid-view-feed.63e32abe07d22ffa4c62.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/grocery-coupon-sd-card.a084fbbfc8c9d91d69d7.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/grocery-coupon-sd-card~shopping-card-wce.329bc610b8fce0423344.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/horizontal-nav.829d73beedaa0f2c4b53.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/horoscope-answer-card-wc.76ab2ff3855ff174a029.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/inline-head.c103a446ec0fbac9f1ef.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/interests-wc.63f57db7a653fdea93a0.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/interests-wc~notification-bell-wc.b3797d5a6c5651c5b71f.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/layout-toggle.76bef0516dbcee207854.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/layoutPreferenceData.2eeb799af222176f9814.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/linear-view-feed.eef8bc0faf4fedb0c09f.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/linked-in-card.3bf35da964bc72aa46fd.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/lottery-card.ff41c056f85b78896791.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/marketplace-card-wc.a8306d57ea9211365e82.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/money-info-card-wc.7095a109d00408f7ea46.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/ms-rewards-wc.42c65d5fe5ae0677f659.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/msccCookieBanner.816d4490ee4af71ae588.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/native-ad-wc.fd232ea9f43d79ee5a4b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/nativeadsdecorations.953441c720464e225980.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/news-segment-carousel.6393fa4158f497de6948.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/newsbar-toggle.06683a975c79be310faa.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/notification-bell-wc.c7f262fc28e3e0ac1246.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/ocvFeedback.4c2cc09ee0d7118996b2.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/office-feed.1929117322f76bd3a35c.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/on-this-day-card-wc.fedcaa58a9b0a3942cb2.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/outlook-email-preview-wc.1626df45a6299a22520f.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/overlay-wc.f54a4f4621d490da3868.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/page-error-handling.098fe6153e9b0e8b6762.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/pill-wc.98910025a007f415f08b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/pivots-nav-edgenext.7745e23d12095d571f35.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/poweredby-legend-wc.283acda708890088675b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/prism-sd-card.a62be2ff47b8b0f927d9.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/publisher-carousel.2e993bea1aa7941c461e.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/qna-card.3ee2efeddb2a1dbfa9bb.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/reaction-breakdown-dialog.73b4ff2710a096bcda3c.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/recipes-sd-card.26704528584f5cbd7685.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	web_custom_request("logout", 
		"URL=http://private.proverki.local/public/auth/authenticator/api/internalauth/logout", 
		"Method=DELETE", 
		"Resource=0", 
		"Referer=http://private.proverki.local/private/knms", 
		"Snapshot=t223.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_url("organizations_3", 
		"URL=http://private.proverki.local/erknm-catalogs/api/general-info/organizations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://private.proverki.local/private/lk", 
		"Snapshot=t224.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/recommended-search-carousel-wc.eefd2400115a56202325.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/rewards-card-wc.878a388de9f21d48cb1f.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/RewardsData.4f81de555273ecf6f1ea.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/right-rail-cards.668cde93d6ffb36ddba0.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/search-history-edgenext-wc.5552c3e4ff978ea4494b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/select-carousel.412eba4b4c1d2526210b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/settings-dialog-edgenext-wc.7241d1528795f3a13db6.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/sharepoint-news-card.3f248cefa7ea06944fcb.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/shopping-card-wce.4573ab34a86818d5dca6.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/shopping-smart-list.b50437b40ea21d246352.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/side-bar.91201bbcc36361a0451c.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/sign-in-banner-wc.4ba763c73340a390662a.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/sign-in-control-wc.38ac6286358c6d376a76.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/sign-in-flyout-wc.f23a889ea7d05ba24c94.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/social-bar-wc.a7514f1cccf8fad5b509.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/social-profile-carousel-premium.54d5f0405a3fac605f08.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/social-profile-carousel.b0f0ecae98660cfde92c.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/sports-card-wc.98a3f2f938a948cec0c4.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/sports-olympic-card-wc.bc21e935bee6510e6d1b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/sticky-peek.0e141c8976ef8af2712a.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/toast-wc.601efe3ea7cfcdf73372.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/topicData.e9f0169494da3e638bf0.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/traffic-card-wc.f1f6eabe945396c97a19.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/travel-destination.cff661f2f486d3aae479.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/trendingNowWC.6f5e51eaf3ef610b12c5.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/trendingTopics.23f495bfe46044d162f9.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/vertical-left-nav.6593ccac20333a0203d2.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/videoCard.c3240c9259b6818eb9c4.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/voice-search-wc.f1f88206660655768a2c.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/waffle-wc.d1ca2d1ed6066ee5ef2f.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/weather-data-connector.6a90b4a11fe34be2196e.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/weather-data-lazy-services.3d97af7a2827b3c21e4b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/web-worker.41f00c5f302731460ad4.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/welcomeGreeting.81e2c28172963bf5cfd0.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/xbox-feed-wc.c86e4ef016adf11dd095.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		"Url=https://assets.msn.com/bundles/v1/edgeChromium/latest/xfeed.39afe170c76f8d853f4b.js", "Referer=https://ntp.msn.com/", ENDITEM, 
		LAST);

	return 0;
}
